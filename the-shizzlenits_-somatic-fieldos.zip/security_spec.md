# DATA INVARIANTS:
1. A note or source cannot be created without a valid folderId (using 'root' if not in any specific folder) and owner's userId matching the authenticated user.
2. Modifications of any resource in `folders`, `notes`, or `sources` must reject if the current authenticated user is not the owner (matching the document's `userId` field).
3. The folder ID inside a note or source must point to an existing folderId, or be 'root'.
4. Immutability checks: `userId` (owner) cannot be altered on update. `createdAt` remains unchanged after creation. `updatedAt` on a note must be matching requests time or last changed.

# DIRTY DOZEN PAYLOADS:
1. Write to folders with a shadow field `isAdmin: true`
2. Write to folders using another user's UID as `userId`
3. Update folders trying to modify other fields besides `name` and `description` (e.g. `createdAt`)
4. Create a folder with a random payload shape containing excess properties
5. Create a note with extremely large mock content trying to exhaust system storage limits
6. Write a note with a `title` as an array or boolean instead of a string
7. Create a note with other user's owner `userId`
8. Update a note owned by user-A using auth-B credentials
9. Write a source with a `url` exceeding allowed character limit
10. Create a source with missing required fields
11. Update notes to clear out `userId` or set it to null
12. Attempt to list the entire collection of `notes` across all users (unfiltered list query)

# TEST RUNNER:
Tests verifying that the dirty payloads get blocked and correct user queries pass are executed within the sandbox and backend logic. Our rules validate each of these conditions.
