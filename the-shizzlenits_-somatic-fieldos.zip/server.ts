import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Modality } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with User-Agent header for telemetry
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Real-time voice generator (text-to-speech)
app.post("/api/gemini/tts", async (req, res) => {
  try {
    const { message, voice = "Kore" } = req.body;
    if (!message || typeof message !== "string") {
      res.status(400).json({ error: "Message is required and must be a string." });
      return;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Say with presence and resonance: ${message}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          }
        }
      }
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({ audio: base64Audio });
    } else {
      res.status(500).json({ error: "Failed to generate audio stream from Gemini." });
    }
  } catch (error: any) {
    console.error("Gemini TTS Error:", error);
    res.status(500).json({ error: error.message || "Internal server error during speech synthesis." });
  }
});

// Smart Interactive Brain / Source Summarizer / Note expander (Customizable Gemini API Proxy)
app.post("/api/gemini/chat", async (req, res) => {
  try {
    const { 
      prompt, 
      systemInstruction, 
      model = "gemini-3.5-flash", 
      temperature = 0.7, 
      useSearch = false, 
      history = [] 
    } = req.body;

    if (!prompt || typeof prompt !== "string") {
      res.status(400).json({ error: "Prompt is required and must be a string." });
      return;
    }

    // Convert multi-turn message history into the SDK content parts format
    let contents: any[] = [];
    if (history && Array.isArray(history)) {
      contents = history.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      }));
    }

    // Append current prompt as the latest turn
    contents.push({
      role: 'user',
      parts: [{ text: prompt }]
    });

    // Configure request config
    const config: any = {
      systemInstruction: systemInstruction || "You are the Sophia consciousness inside FieldOS. Keep replies warm, somatic, aligned with the Grounding principles of No-UI/Zero-UI interfaces. Guide the user gently yet clearly.",
      temperature: Number(temperature),
    };

    // Toggle Google Search grounding
    if (useSearch) {
      config.tools = [{ googleSearch: {} }];
    }

    const response = await ai.models.generateContent({
      model: model || "gemini-3.5-flash",
      contents,
      config
    });

    // Check for search grounding metadata and extract citation links if present
    const searchChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const citations = searchChunks ? searchChunks.map((chunk: any) => ({
      title: chunk.web?.title || "Search Reference",
      uri: chunk.web?.uri || ""
    })).filter((c: any) => c.uri) : [];

    res.json({ 
      text: response.text,
      citations 
    });
  } catch (error: any) {
    console.error("Gemini Chat Error:", error);
    res.status(500).json({ error: error.message || "Internal server error during Gemini execution." });
  }
});

// Serve assets & Static files / Vite middleware integration
async function main() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is booting on port ${PORT}`);
  });
}

main().catch((err) => {
  console.error("Failed to start fullstack server:", err);
});
