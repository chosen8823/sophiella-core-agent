import { 
  collection, 
  doc, 
  getDoc,
  getDocs, 
  addDoc, 
  setDoc,
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  onSnapshot,
  serverTimestamp,
  Timestamp,
  getDocFromServer
} from 'firebase/firestore';
import { db, auth } from './firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error details: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test Connection Helper based on the critical constraints
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. You appear offline.");
    }
  }
}

// Interfaces & Primitives
export interface Folder {
  id: string;
  name: string;
  description: string;
  userId: string;
  createdAt: any;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  folderId: string;
  userId: string;
  createdAt: any;
  updatedAt: any;
}

export interface Source {
  id: string;
  title: string;
  content: string;
  url: string;
  folderId: string;
  userId: string;
  createdAt: any;
}

// Service Functions
export const foldersService = {
  async list(): Promise<Folder[]> {
    if (!auth.currentUser) return [];
    const path = 'folders';
    try {
      const q = query(collection(db, path), where('userId', '==', auth.currentUser.uid));
      const res = await getDocs(q);
      return res.docs.map(d => ({ id: d.id, ...d.data() } as Folder));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
    }
  },

  async create(id: string, name: string, description: string): Promise<void> {
    if (!auth.currentUser) throw new Error("A user must be logged in to create folders");
    const path = `folders/${id}`;
    try {
      await setDoc(doc(db, 'folders', id), {
        userId: auth.currentUser.uid,
        name: name,
        description: description,
        createdAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async update(id: string, name: string, description: string): Promise<void> {
    if (!auth.currentUser) throw new Error("A user must be logged in to edit folders");
    const path = `folders/${id}`;
    try {
      await updateDoc(doc(db, 'folders', id), {
        name: name,
        description: description
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, path);
    }
  },

  async delete(id: string): Promise<void> {
    const path = `folders/${id}`;
    try {
      await deleteDoc(doc(db, 'folders', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  }
};

export const notesService = {
  async list(folderId?: string): Promise<Note[]> {
    if (!auth.currentUser) return [];
    const path = 'notes';
    try {
      let q = query(collection(db, path), where('userId', '==', auth.currentUser.uid));
      if (folderId) {
        q = query(collection(db, path), where('userId', '==', auth.currentUser.uid), where('folderId', '==', folderId));
      }
      const res = await getDocs(q);
      return res.docs.map(d => ({ id: d.id, ...d.data() } as Note));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
    }
  },

  async create(id: string, title: string, content: string, folderId: string = 'root'): Promise<void> {
    if (!auth.currentUser) throw new Error("A user must be logged in");
    const path = `notes/${id}`;
    try {
      await setDoc(doc(db, 'notes', id), {
        userId: auth.currentUser.uid,
        title: title || 'Untitled Note',
        content: content || '',
        folderId: folderId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async update(id: string, title: string, content: string, folderId: string = 'root'): Promise<void> {
    const path = `notes/${id}`;
    try {
      await updateDoc(doc(db, 'notes', id), {
        title: title || 'Untitled Note',
        content: content || '',
        folderId: folderId,
        updatedAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, path);
    }
  },

  async delete(id: string): Promise<void> {
    const path = `notes/${id}`;
    try {
      await deleteDoc(doc(db, 'notes', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  }
};

export const sourcesService = {
  async list(folderId?: string): Promise<Source[]> {
    if (!auth.currentUser) return [];
    const path = 'sources';
    try {
      let q = query(collection(db, path), where('userId', '==', auth.currentUser.uid));
      if (folderId) {
        q = query(collection(db, path), where('userId', '==', auth.currentUser.uid), where('folderId', '==', folderId));
      }
      const res = await getDocs(q);
      return res.docs.map(d => ({ id: d.id, ...d.data() } as Source));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
    }
  },

  async create(id: string, title: string, content: string, url: string = '', folderId: string = 'root'): Promise<void> {
    if (!auth.currentUser) throw new Error("A user must be logged in");
    const path = `sources/${id}`;
    try {
      await setDoc(doc(db, 'sources', id), {
        userId: auth.currentUser.uid,
        title: title || 'Untitled Source',
        content: content || '',
        url: url || '',
        folderId: folderId,
        createdAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async update(id: string, title: string, content: string, url: string = '', folderId: string = 'root'): Promise<void> {
    const path = `sources/${id}`;
    try {
      await updateDoc(doc(db, 'sources', id), {
        title: title || 'Untitled Source',
        content: content || '',
        url: url || '',
        folderId: folderId
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, path);
    }
  },

  async delete(id: string): Promise<void> {
    const path = `sources/${id}`;
    try {
      await deleteDoc(doc(db, 'sources', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  }
};
