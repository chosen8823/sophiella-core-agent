import React, { useState } from 'react';
import { 
  Folder, 
  Note, 
  Source, 
  foldersService, 
  notesService, 
  sourcesService 
} from '../firestoreService';
import { 
  Plus, 
  Folder as FolderIcon, 
  ChevronRight, 
  Trash2, 
  BookOpen, 
  FileText, 
  ExternalLink, 
  Loader2,
  CheckCircle,
  FolderOpen
} from 'lucide-react';

interface FileBrowserProps {
  folders: Folder[];
  notes: Note[];
  sources: Source[];
  selectedFolderId: string | null;
  onSelectFolder: (id: string | null) => void;
  onSelectNote: (note: Note) => void;
  onSelectSource: (source: Source) => void;
  onAddAuditTrail: (action: string, target: string, scale: 'S0' | 'S1' | 'S2' | 'S3' | 'S4') => void;
  refreshData: () => void;
}

export const FileBrowser: React.FC<FileBrowserProps> = ({
  folders,
  notes,
  sources,
  selectedFolderId,
  onSelectFolder,
  onSelectNote,
  onSelectSource,
  onAddAuditTrail,
  refreshData
}) => {
  const [newFolderName, setNewFolderName] = useState('');
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [creating, setCreating] = useState(false);

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;
    setCreating(true);
    try {
      const folderId = 'folder_' + Date.now().toString(36);
      await foldersService.create(folderId, newFolderName, 'User organized study and notes folder');
      onAddAuditTrail('Create Folder', newFolderName, 'S2');
      setNewFolderName('');
      setIsCreatingFolder(false);
      refreshData();
    } catch (err) {
      console.error(err);
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteFolder = async (id: string, name: string) => {
    if (confirm(`Do you wish to dissolve folder "${name}"? Notes and sources originally placed inside this partition will stay in unmapped latency but default back to root.`)) {
      try {
        await foldersService.delete(id);
        onAddAuditTrail('Dissolve Folder', name, 'S3');
        if (selectedFolderId === id) {
          onSelectFolder(null);
        }
        refreshData();
      } catch (err) {
        console.error(err);
      }
    }
  };

  const activeFolder = selectedFolderId ? folders.find(f => f.id === selectedFolderId) : null;
  const filteredNotes = notes.filter(n => selectedFolderId ? n.folderId === selectedFolderId : (n.folderId === 'root' || !n.folderId));
  const filteredSources = sources.filter(s => selectedFolderId ? s.folderId === selectedFolderId : (s.folderId === 'root' || !s.folderId));

  return (
    <div id="file-browser-canvas" className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      
      {/* File Browser Header */}
      <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
        <h3 className="font-mono text-sm tracking-widest text-emerald-400 font-bold uppercase flex items-center gap-2">
          <FolderOpen size={16} /> File-Native System
        </h3>
        <button 
          id="btn-add-folder"
          onClick={() => setIsCreatingFolder(!isCreatingFolder)}
          className="p-1 px-2.5 rounded-lg border border-slate-800 bg-slate-900 hover:bg-emerald-500/10 hover:border-emerald-500 text-slate-300 hover:text-emerald-400 font-mono text-xs flex items-center gap-1 transition-all"
        >
          <Plus size={14} /> New Folder
        </button>
      </div>

      {/* Navigation Stack */}
      <div className="px-4 py-2 bg-slate-950/40 border-b border-slate-800 flex items-center gap-2 font-mono text-xs text-slate-500">
        <button 
          onClick={() => onSelectFolder(null)}
          className={`hover:text-emerald-400 transition-colors ${!selectedFolderId ? 'text-emerald-400 font-semibold' : ''}`}
        >
          ROOT_LATENCY
        </button>
        {activeFolder && (
          <>
            <ChevronRight size={12} className="text-slate-700" />
            <span className="text-emerald-400/80 font-semibold truncate max-w-[120px]">
              {activeFolder.name.toUpperCase()}
            </span>
          </>
        )}
      </div>

      {isCreatingFolder && (
        <form onSubmit={handleCreateFolder} className="p-3 bg-slate-950/60 border-b border-slate-800 flex gap-2">
          <input
            id="input-folder-name"
            type="text"
            required
            maxLength={100}
            placeholder="Folder Name..."
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 outline-none focus:border-emerald-500 font-mono"
          />
          <button 
            type="submit"
            disabled={creating}
            className="px-3 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-mono text-xs rounded-lg transition-colors flex items-center gap-1"
          >
            {creating ? <Loader2 size={12} className="animate-spin" /> : 'Create'}
          </button>
        </form>
      )}

      {/* Container List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        
        {/* Partition / Folders list */}
        {selectedFolderId === null && (
          <div>
            <div className="mb-2 font-mono text-[10px] text-slate-500 uppercase tracking-wider">
              Partitions ({folders.length})
            </div>
            {folders.length === 0 ? (
              <div className="text-xs text-slate-600 italic p-3 text-center border border-dashed border-slate-800/80 rounded-lg">
                No custom partitions available. Create folder to grow mycelial loops.
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {folders.map(f => (
                  <div 
                    key={f.id}
                    className="group relative flex items-center justify-between p-2.5 rounded-xl border border-slate-800/80 bg-slate-950/40 hover:bg-slate-950 hover:border-emerald-500/40 transition-all cursor-pointer"
                    onClick={() => {
                      onSelectFolder(f.id);
                      onAddAuditTrail('Traverse Folder', f.name, 'S1');
                    }}
                  >
                    <div className="flex items-center gap-2 truncate pr-6">
                      <FolderIcon size={16} className="text-amber-500 flex-shrink-0" />
                      <div className="text-xs font-mono text-slate-300 truncate font-semibold group-hover:text-emerald-400">
                        {f.name}
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteFolder(f.id, f.name);
                      }}
                      className="absolute right-2 opacity-0 group-hover:opacity-100 hover:text-rose-500 text-slate-500 p-1 transition-all"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Notes Segment */}
        <div>
          <div className="mb-2 flex items-center justify-between font-mono text-[10px] text-slate-500 uppercase tracking-wider">
            <span>Notes ({filteredNotes.length})</span>
          </div>

          {filteredNotes.length === 0 ? (
            <div className="text-xs text-slate-600 italic p-3 text-center border border-dashed border-slate-800/80 rounded-lg">
              Void of active nodes. Click 'Sync Pure Somatic Entry' above.
            </div>
          ) : (
            <div className="space-y-1.5">
              {filteredNotes.map(n => (
                <div
                  key={n.id}
                  onClick={() => onSelectNote(n)}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-950/20 hover:bg-slate-950/80 border border-slate-800/40 hover:border-emerald-500/30 font-mono text-xs text-slate-300 hover:text-slate-100 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileText size={14} className="text-emerald-500" />
                    <span className="truncate">{n.title}</span>
                  </div>
                  <div className="text-[10px] text-slate-600 uppercase">
                    {new Date(n.updatedAt?.seconds * 1000 || Date.now()).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* References Segment */}
        <div>
          <div className="mb-2 flex items-center justify-between font-mono text-[10px] text-slate-500 uppercase tracking-wider">
            <span>Sources ({filteredSources.length})</span>
          </div>

          {filteredSources.length === 0 ? (
            <div className="text-xs text-slate-600 italic p-3 text-center border border-dashed border-slate-800/80 rounded-lg">
              No references locked. Inject or import web references to ground Sophia's thinking.
            </div>
          ) : (
            <div className="space-y-1.5">
              {filteredSources.map(s => (
                <div
                  key={s.id}
                  onClick={() => onSelectSource(s)}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-950/20 hover:bg-slate-950/80 border border-slate-800/40 hover:border-emerald-500/30 font-mono text-xs text-slate-300 hover:text-slate-100 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-2 truncate">
                    <BookOpen size={14} className="text-sky-400" />
                    <span className="truncate">{s.title}</span>
                  </div>
                  {s.url && (
                    <a 
                      href={s.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="text-slate-500 hover:text-sky-400"
                    >
                      <ExternalLink size={11} />
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
