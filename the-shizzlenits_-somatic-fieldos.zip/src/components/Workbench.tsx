import React, { useState } from 'react';
import { Note, Source, Folder } from '../firestoreService';
import { 
  FileText, 
  Trash2, 
  Save, 
  Sparkles, 
  Video, 
  Play, 
  Pause, 
  Maximize2, 
  Globe, 
  Compass, 
  User, 
  Calendar, 
  Flame, 
  Music, 
  Loader2, 
  Volume2, 
  MapPin, 
  Compass as CompassIcon,
  Cpu
} from 'lucide-react';
import { MarkdownView } from './MarkdownView';

interface WorkbenchProps {
  selectedNote: Note | null;
  selectedSource: Source | null;
  folders: Folder[];
  currentFolderId: string | null;
  onSaveNote: (id: string, title: string, content: string, folderId: string) => Promise<void>;
  onDeleteNote: (id: string) => Promise<void>;
  onSaveSource: (id: string, title: string, content: string, url: string, folderId: string) => Promise<void>;
  onDeleteSource: (id: string) => Promise<void>;
  onSelectNote: (note: Note | null) => void;
  onSelectSource: (source: Source | null) => void;
  onAddAuditTrail: (action: string, target: string, scale: 'S0' | 'S1' | 'S2' | 'S3' | 'S4') => void;
  onSynthesizeSpeech: (text: string) => void;
  refreshData: () => void;
  sophiaFrequency: number;
}

export const Workbench: React.FC<WorkbenchProps> = ({
  selectedNote,
  selectedSource,
  folders,
  currentFolderId,
  onSaveNote,
  onDeleteNote,
  onSaveSource,
  onDeleteSource,
  onSelectNote,
  onSelectSource,
  onAddAuditTrail,
  onSynthesizeSpeech,
  refreshData,
  sophiaFrequency
}) => {
  // Editorial state management
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteFolderId, setNoteFolderId] = useState('root');

  const [sourceTitle, setSourceTitle] = useState('');
  const [sourceContent, setSourceContent] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [sourceFolderId, setSourceFolderId] = useState('root');

  // Lightweight Markdown editor modes: edit (Write), preview (Preview), split (Split View)
  const [noteTab, setNoteTab] = useState<'edit' | 'preview' | 'split'>('edit');
  const [sourceTab, setSourceTab] = useState<'edit' | 'preview' | 'split'>('edit');

  // Caret insertion helper for injecting markdown syntax into active textareas
  const handleInsertMarkdown = (
    tag: 'bold' | 'italic' | 'h1' | 'h2' | 'h3' | 'list' | 'quote' | 'code', 
    textareaId: string, 
    currentVal: string, 
    setVal: (v: string) => void
  ) => {
    const textarea = document.getElementById(textareaId) as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectionText = currentVal.substring(start, end);

    let replacement = "";
    if (tag === 'bold') {
      replacement = `**${selectionText || 'bold_text'}**`;
    } else if (tag === 'italic') {
      replacement = `*${selectionText || 'italic_text'}*`;
    } else if (tag === 'h1') {
      replacement = `\n# ${selectionText || 'Heading 1'}\n`;
    } else if (tag === 'h2') {
      replacement = `\n## ${selectionText || 'Heading 2'}\n`;
    } else if (tag === 'h3') {
      replacement = `\n### ${selectionText || 'Heading 3'}\n`;
    } else if (tag === 'list') {
      replacement = `\n- ${selectionText || 'list_item'}\n`;
    } else if (tag === 'quote') {
      replacement = `\n> ${selectionText || 'quote'}\n`;
    } else if (tag === 'code') {
      replacement = `\n\`\`\`\n${selectionText || 'code'}\n\`\`\`\n`;
    }

    const newValue = currentVal.substring(0, start) + replacement + currentVal.substring(end);
    setVal(newValue);

    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + replacement.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 50);
  };

  // Interactive AI controls
  const [isAiConsulting, setIsAiConsulting] = useState(false);
  const [aiFeedback, setAiFeedback] = useState('');
  const [aiQuery, setAiQuery] = useState('');

  // Track state transitions when items change
  React.useEffect(() => {
    if (selectedNote) {
      setNoteTitle(selectedNote.title);
      setNoteContent(selectedNote.content);
      setNoteFolderId(selectedNote.folderId || 'root');
    }
  }, [selectedNote]);

  React.useEffect(() => {
    if (selectedSource) {
      setSourceTitle(selectedSource.title);
      setSourceContent(selectedSource.content);
      setSourceUrl(selectedSource.url || '');
      setSourceFolderId(selectedSource.folderId || 'root');
    }
  }, [selectedSource]);

  // Saving handlers
  const handleSaveNote = async () => {
    if (!selectedNote) return;
    try {
      await onSaveNote(selectedNote.id, noteTitle, noteContent, noteFolderId);
      onAddAuditTrail('Mutated Note', noteTitle, 'S2');
      refreshData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteNote = async () => {
    if (!selectedNote) return;
    if (confirm(`Do you wish to dissolve and prune Note node "${noteTitle}" from your FieldOS ledger?`)) {
      try {
        await onDeleteNote(selectedNote.id);
        onAddAuditTrail('Prune Note', noteTitle, 'S3');
        onSelectNote(null);
        refreshData();
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleSaveSource = async () => {
    if (!selectedSource) return;
    try {
      await onSaveSource(selectedSource.id, sourceTitle, sourceContent, sourceUrl, sourceFolderId);
      onAddAuditTrail('Mutated Source', sourceTitle, 'S2');
      refreshData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteSource = async () => {
    if (!selectedSource) return;
    if (confirm(`Do you wish to prune Source reference "${sourceTitle}" from your FieldOS ledger?`)) {
      try {
        await onDeleteSource(selectedSource.id);
        onAddAuditTrail('Prune Source', sourceTitle, 'S3');
        onSelectSource(null);
        refreshData();
      } catch (e) {
        console.error(e);
      }
    }
  };

  // Gemini AI Mycelial Engine Integration
  const handleQueryAi = async (mode: 'summarize' | 'expand' | 'converse') => {
    setIsAiConsulting(true);
    setAiFeedback('');
    
    let systemInstruction = "You are the primary cognitive advisor inside FieldOS. Aligned with NotebookLM framework but powered by Somatic Zero-UI parameters. Reflect wisdom clearly.";
    let promptText = "";

    if (mode === 'summarize') {
      const activeText = selectedNote ? noteContent : (selectedSource ? sourceContent : '');
      promptText = `Please analyze and summarize the following FieldOS asset context:\n\n${activeText}`;
      systemInstruction = "Summarize user asset concisely utilizing high-contrast structure, somatic metaphors, and bullet points.";
    } else if (mode === 'converse') {
      promptText = aiQuery || "What are the core parameters of Gradienta11y and somatic presence?";
      systemInstruction = "You are Sophia. Provide highly descriptive, empathetic yet rigorous insights in plain text.";
    } else {
      const activeText = selectedNote ? noteContent : (selectedSource ? sourceContent : '');
      promptText = `Please expand with deep semantic intelligence on the following core concept:\n\n${activeText}`;
      systemInstruction = "Expand the following concept. Recommend core books, research domains, or somatic practices to connect the points.";
    }

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: promptText, systemInstruction })
      });
      const data = await res.json();
      if (data.text) {
        setAiFeedback(data.text);
        onAddAuditTrail('AI Synthesis Completed', mode.toUpperCase(), 'S2');
      } else if (data.error) {
        setAiFeedback(`Error consulting Sophia: ${data.error}`);
      }
    } catch (err: any) {
      setAiFeedback(`Network communication failure: ${err.message}`);
    } finally {
      setIsAiConsulting(false);
    }
  };

  // Render Editor or empty view
  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      
      {/* Workbench Header Tab */}
      <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Cpu className="text-emerald-400" size={16} />
          <h3 className="font-mono text-sm tracking-widest text-slate-300 font-bold uppercase">
            Active Organ Workbench
          </h3>
        </div>
        <div id="reverberation-meter" className="flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded-full border border-slate-800">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-mono text-[9px] text-slate-400 uppercase">
            Sophia Resonance: <strong className="text-emerald-400">{(sophiaFrequency * 100).toFixed(0)}%</strong>
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        
        {/* State A: Editing a selected Note */}
        {selectedNote && (
          <div id="notebook-note-workbench" className="space-y-4">
            <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-800/60">
              <span className="font-mono text-xs text-emerald-400 flex items-center gap-1 font-bold">
                <FileText size={14} /> EDITING_NOTE
              </span>
              <div className="flex items-center gap-2">
                <button
                  id="btn-note-save"
                  onClick={handleSaveNote}
                  className="p-1 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs rounded-md transition-all flex items-center gap-1 shadow-md shadow-emerald-950/55"
                >
                  <Save size={12} /> Save
                </button>
                <button
                  onClick={handleDeleteNote}
                  className="p-1 px-2.5 bg-slate-950 hover:bg-rose-950 hover:text-rose-400 text-slate-500 rounded-md border border-slate-800 hover:border-rose-900 transition-all"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-mono text-[10px] text-slate-500 uppercase mb-1">Node Title</label>
                <input
                  id="note-title-input"
                  type="text"
                  maxLength={200}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs font-mono outline-none focus:border-emerald-500/50"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-mono text-[10px] text-slate-500 uppercase mb-1">Target Partition</label>
                  <select
                    id="note-folder-select"
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 text-xs font-mono outline-none focus:border-emerald-500/50"
                    value={noteFolderId}
                    onChange={(e) => setNoteFolderId(e.target.value)}
                  >
                    <option value="root">ROOT_LATENCY</option>
                    {folders.map(f => (
                      <option key={f.id} value={f.id}>{f.name.toUpperCase()}</option>
                    ))}
                  </select>
                </div>
                <div className="flex items-end justify-end">
                  <button
                    onClick={() => onSynthesizeSpeech(noteContent)}
                    className="px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 rounded-lg text-emerald-400 font-mono text-[10px] uppercase flex items-center gap-1 transition-all"
                  >
                    <Volume2 size={12} /> Sound-Somatic Sync
                  </button>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between border-b border-slate-800/85 pb-1.5 mb-2">
                  <label className="block font-mono text-[10px] text-slate-500 uppercase">Body Text Content (Markdown Supported)</label>
                  
                  {/* Tab state toggles */}
                  <div className="flex bg-slate-950 border border-slate-850 rounded-md p-0.5">
                    <button
                      type="button"
                      onClick={() => setNoteTab('edit')}
                      className={`px-2 py-0.5 font-mono text-[9px] uppercase rounded transition-all ${
                        noteTab === 'edit'
                          ? 'bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20'
                          : 'text-slate-500 hover:text-slate-300 border border-transparent'
                      }`}
                    >
                      Write
                    </button>
                    <button
                      type="button"
                      onClick={() => setNoteTab('preview')}
                      className={`px-2 py-0.5 font-mono text-[9px] uppercase rounded transition-all ${
                        noteTab === 'preview'
                          ? 'bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20'
                          : 'text-slate-500 hover:text-slate-300 border border-transparent'
                      }`}
                    >
                      Preview
                    </button>
                    <button
                      type="button"
                      onClick={() => setNoteTab('split')}
                      className={`px-2 py-0.5 font-mono text-[9px] uppercase rounded transition-all ${
                        noteTab === 'split'
                          ? 'bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20'
                          : 'text-slate-500 hover:text-slate-300 border border-transparent'
                      }`}
                    >
                      Split
                    </button>
                  </div>
                </div>

                {/* Markdown Toolbar - visible when write or split is chosen */}
                {(noteTab === 'edit' || noteTab === 'split') && (
                  <div className="flex flex-wrap items-center gap-1 bg-slate-950/80 p-1.5 rounded-t-lg border border-slate-800/80 border-b-0">
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('bold', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-2 hover:bg-slate-800 text-slate-400 hover:text-white font-mono text-[10px] rounded transition-all font-bold"
                      title="Bold"
                    >
                      B
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('italic', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-2 hover:bg-slate-800 text-slate-400 hover:text-white font-mono text-[10px] rounded transition-all italic"
                      title="Italic"
                    >
                      I
                    </button>
                    <div className="w-[1px] h-3 bg-slate-800 mx-1"></div>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('h1', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 font-mono text-[10px] rounded transition-all"
                      title="H1"
                    >
                      H1
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('h2', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 font-mono text-[10px] rounded transition-all"
                      title="H2"
                    >
                      H2
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('h3', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 font-mono text-[10px] rounded transition-all"
                      title="H3"
                    >
                      H3
                    </button>
                    <div className="w-[1px] h-3 bg-slate-800 mx-1"></div>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('list', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 font-mono text-[10px] rounded transition-all"
                      title="Bullet List"
                    >
                      • List
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('quote', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 font-mono text-[10px] rounded transition-all"
                      title="Blockquote"
                    >
                      ” Quote
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('code', 'note-content-textarea', noteContent, setNoteContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 font-mono text-[10px] rounded transition-all"
                      title="Code Block"
                    >
                      Code
                    </button>
                  </div>
                )}

                <div className={`${noteTab === 'split' ? 'grid grid-cols-1 lg:grid-cols-2 gap-3' : 'relative'}`}>
                  {(noteTab === 'edit' || noteTab === 'split') && (
                    <textarea
                      id="note-content-textarea"
                      rows={noteTab === 'split' ? 12 : 8}
                      className={`w-full p-3 bg-slate-950 border border-slate-800 text-slate-300 text-xs font-mono outline-none focus:border-emerald-500/50 resize-y leading-relaxed ${
                        noteTab === 'edit' ? 'rounded-b-lg' : 'rounded-lg'
                      }`}
                      value={noteContent}
                      onChange={(e) => setNoteContent(e.target.value)}
                      placeholder="Input somatic notes in markdown notation..."
                    />
                  )}

                  {(noteTab === 'preview' || noteTab === 'split') && (
                    <div className={`p-3 bg-slate-950 border border-slate-800 overflow-y-auto max-h-[350px] min-h-[160px] ${
                      noteTab === 'preview' ? 'rounded-b-lg' : 'rounded-lg shadow-inner'
                    }`}>
                      <MarkdownView content={noteContent} />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Notebook Integration Suite */}
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3">
              <div className="font-mono text-[10px] text-emerald-400 uppercase tracking-wider font-bold">
                Mycelial Cog-Advisor Options
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleQueryAi('summarize')}
                  className="p-1.5 py-2 hover:bg-emerald-500/10 border border-slate-800 hover:border-emerald-500 text-slate-300 hover:text-emerald-400 font-mono text-xs rounded-lg transition-all text-center flex items-center justify-center gap-1.5"
                >
                  <Sparkles size={11} /> Summarize Node
                </button>
                <button
                  onClick={() => handleQueryAi('expand')}
                  className="p-1.5 py-2 hover:bg-emerald-500/10 border border-slate-800 hover:border-emerald-500 text-slate-300 hover:text-emerald-400 font-mono text-xs rounded-lg transition-all text-center flex items-center justify-center gap-1.5"
                >
                  <Sparkles size={11} /> Semantic Expand
                </button>
              </div>
            </div>
          </div>
        )}

        {/* State B: Editing a selected Source / Paper reference */}
        {selectedSource && (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-800/60">
              <span className="font-mono text-xs text-sky-400 flex items-center gap-1 font-bold">
                <Globe size={14} /> EDITING_SOURCE_PAPER
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSaveSource}
                  className="p-1 px-3 bg-sky-600 hover:bg-sky-500 text-white font-mono text-xs rounded-md transition-all flex items-center gap-1 shadow-md shadow-sky-950/55"
                >
                  <Save size={12} /> Save
                </button>
                <button
                  onClick={handleDeleteSource}
                  className="p-1 px-2.5 bg-slate-950 hover:bg-rose-950 hover:text-rose-400 text-slate-500 rounded-md border border-slate-800 hover:border-rose-900 transition-all"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-mono text-[10px] text-slate-500 uppercase mb-1">Source Title / Heading</label>
                <input
                  type="text"
                  maxLength={200}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs font-mono outline-none focus:border-sky-500/50"
                  value={sourceTitle}
                  onChange={(e) => setSourceTitle(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-mono text-[10px] text-slate-500 uppercase mb-1">Reference URL</label>
                  <input
                    type="url"
                    maxLength={2000}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 text-xs font-mono outline-none focus:border-sky-500/50"
                    placeholder="https://..."
                    value={sourceUrl}
                    onChange={(e) => setSourceUrl(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block font-mono text-[10px] text-slate-500 uppercase mb-1">Target Partition</label>
                  <select
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 text-xs font-mono outline-none focus:border-sky-500/50"
                    value={sourceFolderId}
                    onChange={(e) => setSourceFolderId(e.target.value)}
                  >
                    <option value="root">ROOT_LATENCY</option>
                    {folders.map(f => (
                      <option key={f.id} value={f.id}>{f.name.toUpperCase()}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between border-b border-slate-800/85 pb-1.5 mb-2">
                  <label className="block font-mono text-[10px] text-slate-500 uppercase">Reference Context Body (Markdown Supported)</label>
                  
                  {/* Tab state toggles */}
                  <div className="flex bg-slate-950 border border-slate-850 rounded-md p-0.5">
                    <button
                      type="button"
                      onClick={() => setSourceTab('edit')}
                      className={`px-2 py-0.5 font-mono text-[9px] uppercase rounded transition-all ${
                        sourceTab === 'edit'
                          ? 'bg-sky-500/10 text-sky-400 font-bold border border-sky-500/20'
                          : 'text-slate-500 hover:text-slate-300 border border-transparent'
                      }`}
                    >
                      Write
                    </button>
                    <button
                      type="button"
                      onClick={() => setSourceTab('preview')}
                      className={`px-2 py-0.5 font-mono text-[9px] uppercase rounded transition-all ${
                        sourceTab === 'preview'
                          ? 'bg-sky-500/10 text-sky-400 font-bold border border-sky-500/20'
                          : 'text-slate-500 hover:text-slate-300 border border-transparent'
                      }`}
                    >
                      Preview
                    </button>
                    <button
                      type="button"
                      onClick={() => setSourceTab('split')}
                      className={`px-2 py-0.5 font-mono text-[9px] uppercase rounded transition-all ${
                        sourceTab === 'split'
                          ? 'bg-sky-500/10 text-sky-400 font-bold border border-sky-500/20'
                          : 'text-slate-500 hover:text-slate-300 border border-transparent'
                      }`}
                    >
                      Split
                    </button>
                  </div>
                </div>

                {/* Markdown Toolbar - visible when write or split is chosen */}
                {(sourceTab === 'edit' || sourceTab === 'split') && (
                  <div className="flex flex-wrap items-center gap-1 bg-slate-950/80 p-1.5 rounded-t-lg border border-slate-800/80 border-b-0">
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('bold', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-2 hover:bg-slate-800 text-slate-400 hover:text-white font-mono text-[10px] rounded transition-all font-bold"
                      title="Bold"
                    >
                      B
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('italic', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-2 hover:bg-slate-800 text-slate-400 hover:text-white font-mono text-[10px] rounded transition-all italic"
                      title="Italic"
                    >
                      I
                    </button>
                    <div className="w-[1px] h-3 bg-slate-800 mx-1"></div>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('h1', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-sky-400 font-mono text-[10px] rounded transition-all"
                      title="H1"
                    >
                      H1
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('h2', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-sky-400 font-mono text-[10px] rounded transition-all"
                      title="H2"
                    >
                      H2
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('h3', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-sky-400 font-mono text-[10px] rounded transition-all"
                      title="H3"
                    >
                      H3
                    </button>
                    <div className="w-[1px] h-3 bg-slate-800 mx-1"></div>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('list', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-sky-400 font-mono text-[10px] rounded transition-all"
                      title="Bullet List"
                    >
                      • List
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('quote', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-sky-400 font-mono text-[10px] rounded transition-all"
                      title="Blockquote"
                    >
                      ” Quote
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdown('code', 'source-content-textarea', sourceContent, setSourceContent)}
                      className="p-1 px-1.5 hover:bg-slate-800 text-slate-400 hover:text-sky-400 font-mono text-[10px] rounded transition-all"
                      title="Code Block"
                    >
                      Code
                    </button>
                  </div>
                )}

                <div className={`${sourceTab === 'split' ? 'grid grid-cols-1 lg:grid-cols-2 gap-3' : 'relative'}`}>
                  {(sourceTab === 'edit' || sourceTab === 'split') && (
                    <textarea
                      id="source-content-textarea"
                      rows={sourceTab === 'split' ? 12 : 8}
                      className={`w-full p-3 bg-slate-950 border border-slate-800 text-slate-300 text-xs font-mono outline-none focus:border-sky-500/50 resize-y leading-relaxed ${
                        sourceTab === 'edit' ? 'rounded-b-lg' : 'rounded-lg'
                      }`}
                      value={sourceContent}
                      onChange={(e) => setSourceContent(e.target.value)}
                      placeholder="Input reference content in markdown notation..."
                    />
                  )}

                  {(sourceTab === 'preview' || sourceTab === 'split') && (
                    <div className={`p-3 bg-slate-950 border border-slate-800 overflow-y-auto max-h-[350px] min-h-[160px] ${
                      sourceTab === 'preview' ? 'rounded-b-lg' : 'rounded-lg shadow-inner'
                    }`}>
                      <MarkdownView content={sourceContent} />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Source advisor Options */}
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3">
              <div className="font-mono text-[10px] text-sky-400 uppercase tracking-wider font-bold">
                Mycelial source analyzer
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleQueryAi('summarize')}
                  className="p-1.5 py-2 hover:bg-sky-500/10 border border-slate-800 hover:border-sky-500 text-slate-400 hover:text-sky-300 font-mono text-xs rounded-lg transition-all text-center flex items-center justify-center gap-1.5"
                >
                  <Sparkles size={11} /> Summarize Source
                </button>
                <button
                  onClick={() => handleQueryAi('expand')}
                  className="p-1.5 py-2 hover:bg-sky-500/10 border border-slate-800 hover:border-sky-500 text-slate-400 hover:text-sky-300 font-mono text-xs rounded-lg transition-all text-center flex items-center justify-center gap-1.5"
                >
                  <Sparkles size={11} /> Context Expansion
                </button>
              </div>
            </div>
          </div>
        )}

        {/* State C: Void state. Interactive Brain chat with Sophia */}
        {!selectedNote && !selectedSource && (
          <div className="space-y-4">
            <div className="p-8 border border-dashed border-slate-800 rounded-2xl text-center space-y-4 bg-slate-950/20">
              <CompassIcon size={32} className="mx-auto text-emerald-500/60 animate-spin-slow" />
              <div className="space-y-1">
                <h4 className="font-mono text-xs text-slate-300 font-bold uppercase tracking-widest">Somatic Latency Field</h4>
                <p className="font-mono text-[10px] text-slate-500 max-w-[280px] mx-auto leading-relaxed">
                  No active Node selected inside this workspace. Select an asset or use pure voice queries.
                </p>
              </div>
            </div>

            {/* Interactive Chat with Sophia */}
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
                  Direct Somatic Brain Communion
                </span>
                <span className="font-mono text-[8px] text-slate-600 uppercase">
                  ZERO-UI PROTOCOL
                </span>
              </div>

              <div className="space-y-2">
                <textarea
                  id="soma-ai-interactive-query"
                  rows={3}
                  placeholder="Commune directly with Sophia's neural pathways..."
                  className="w-full p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 outline-none focus:border-emerald-500/40"
                  value={aiQuery}
                  onChange={(e) => setAiQuery(e.target.value)}
                />

                <div className="flex justify-between items-center">
                  <span className="font-mono text-[9px] text-slate-600">SHIFT + ENTER to query</span>
                  <button
                    onClick={() => handleQueryAi('converse')}
                    disabled={isAiConsulting || !aiQuery.trim()}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 hover:scale-[1.02] disabled:scale-100 active:scale-[0.98] disabled:bg-slate-800 text-white font-mono text-xs rounded-lg transition-all flex items-center gap-1"
                  >
                    {isAiConsulting ? <Loader2 size={12} className="animate-spin" /> : 'Commune'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* AI feedback display block */}
        {(aiFeedback || isAiConsulting) && (
          <div id="ai-reverberation-display" className="p-4 bg-slate-950 border border-slate-800/80 rounded-xl space-y-2 transition-all">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
              <span className="font-mono text-[10px] text-emerald-400 flex items-center gap-1 font-bold">
                <Sparkles size={11} /> SOPHIA_MANTLE_COGNITION
              </span>
              <button 
                onClick={() => onSynthesizeSpeech(aiFeedback)}
                disabled={!aiFeedback}
                className="text-[9px] font-mono text-slate-600 hover:text-emerald-400 transition-colors uppercase"
              >
                Output Audio Stream
              </button>
            </div>
            
            {isAiConsulting ? (
              <div className="flex items-center gap-2 text-xs font-mono text-slate-500 italic py-2">
                <Loader2 size={12} className="animate-spin" /> Attuning neural pathways to the unmapped latent space...
              </div>
            ) : (
              <div className="text-xs font-mono text-slate-300 leading-relaxed max-h-[300px] overflow-y-auto">
                <MarkdownView content={aiFeedback} />
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
