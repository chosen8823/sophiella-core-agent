import React from 'react';

interface MarkdownViewProps {
  content: string;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content }) => {
  if (!content) return <p className="text-slate-500 italic font-mono text-[11px]">No active body content.</p>;

  const lines = content.split('\n');
  const renderedElements: React.ReactNode[] = [];
  
  let inCodeBlock = false;
  let codeBlockLines: string[] = [];

  const parseInlineMarkdown = (text: string): React.ReactNode => {
    const parts: React.ReactNode[] = [];
    const regex = /(\*\*.*?\*\*|__.*?__|`.*?`|\*.*?\*|_.*?_|https?:\/\/[^\s]+)/g;
    const tokens = text.split(regex);

    return tokens.map((token, idx) => {
      if (token.startsWith('**') && token.endsWith('**')) {
        return <strong key={idx} className="font-bold text-slate-100">{token.slice(2, -2)}</strong>;
      }
      if (token.startsWith('__') && token.endsWith('__')) {
        return <strong key={idx} className="font-bold text-slate-100">{token.slice(2, -2)}</strong>;
      }
      if (token.startsWith('*') && token.endsWith('*')) {
        return <em key={idx} className="italic text-slate-200">{token.slice(1, -1)}</em>;
      }
      if (token.startsWith('_') && token.endsWith('_')) {
        return <em key={idx} className="italic text-slate-200">{token.slice(1, -1)}</em>;
      }
      if (token.startsWith('`') && token.endsWith('`')) {
        return (
          <code key={idx} className="bg-slate-950 px-1 py-0.5 border border-slate-850 rounded font-mono text-[11px] text-amber-400">
            {token.slice(1, -1)}
          </code>
        );
      }
      if (token.match(/^https?:\/\/[^\s]+$/)) {
        return (
          <a key={idx} href={token} target="_blank" rel="noopener noreferrer" className="text-emerald-400 underline hover:text-emerald-300 break-all font-mono text-[11px]">
            {token}
          </a>
        );
      }
      return token;
    });
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Toggle code blocks
    if (line.trim().startsWith('```')) {
      if (inCodeBlock) {
        renderedElements.push(
          <pre key={`code-${i}`} className="bg-slate-950 p-2.5 my-2 border border-slate-850 rounded-lg font-mono text-[11px] text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed shadow-inner">
            <code>{codeBlockLines.join('\n')}</code>
          </pre>
        );
        codeBlockLines = [];
        inCodeBlock = false;
      } else {
        inCodeBlock = true;
      }
      continue;
    }

    if (inCodeBlock) {
      codeBlockLines.push(line);
      continue;
    }

    // Header 1 (# )
    if (line.startsWith('# ')) {
      renderedElements.push(
        <h1 key={`h1-${i}`} className="text-sm font-mono tracking-widest font-bold text-emerald-400 border-b border-slate-800 pb-1 mt-4 mb-2 uppercase flex items-center gap-1.5">
          <span className="text-slate-600 font-mono text-[9px] select-none font-normal">H1//</span>
          {parseInlineMarkdown(line.slice(2))}
        </h1>
      );
    }
    // Header 2 (## )
    else if (line.startsWith('## ')) {
      renderedElements.push(
        <h2 key={`h2-${i}`} className="text-[12px] font-mono tracking-wide font-semibold text-emerald-300 mt-3 mb-1.5 uppercase flex items-center gap-1.5">
          <span className="text-slate-600 font-mono text-[9px] select-none font-normal">H2//</span>
          {parseInlineMarkdown(line.slice(3))}
        </h2>
      );
    }
    // Header 3 (### )
    else if (line.startsWith('### ')) {
      renderedElements.push(
        <h3 key={`h3-${i}`} className="text-[11px] font-mono font-medium text-slate-200 mt-2 mb-1 flex items-center gap-1.5">
          <span className="text-slate-600 font-mono text-[9px] select-none font-normal">H3//</span>
          {parseInlineMarkdown(line.slice(4))}
        </h3>
      );
    }
    // Bullet item (* / -)
    else if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
      const marker = line.trim().startsWith('* ') ? '* ' : '- ';
      const bulletContent = line.trim().substring(marker.length);
      renderedElements.push(
        <div key={`li-${i}`} className="flex items-start gap-1.5 my-1 pl-1">
          <span className="text-emerald-500 text-xs select-none">▪</span>
          <span className="text-[11px] text-slate-300 font-mono leading-relaxed">{parseInlineMarkdown(bulletContent)}</span>
        </div>
      );
    }
    // Quote (> )
    else if (line.startsWith('> ')) {
      renderedElements.push(
        <blockquote key={`quote-${i}`} className="border-l-2 border-emerald-500 bg-slate-950/40 p-2 my-1.5 rounded-r font-mono text-[11px] text-slate-400 italic leading-relaxed">
          {parseInlineMarkdown(line.slice(2))}
        </blockquote>
      );
    }
    // Ordinary content paragraph
    else {
      if (line.trim() === '') {
        renderedElements.push(<div key={`empty-${i}`} className="h-1.5" />);
      } else {
        renderedElements.push(
          <p key={`p-${i}`} className="text-[11px] font-mono text-slate-300 leading-relaxed my-1">
            {parseInlineMarkdown(line)}
          </p>
        );
      }
    }
  }

  // Handle unclosed block safety
  if (inCodeBlock && codeBlockLines.length > 0) {
    renderedElements.push(
      <pre key={`code-end`} className="bg-slate-950 p-2.5 my-2 border border-slate-850 rounded-lg font-mono text-[11px] text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed shadow-inner">
        <code>{codeBlockLines.join('\n')}</code>
      </pre>
    );
  }

  return <div className="space-y-0.5">{renderedElements}</div>;
};
