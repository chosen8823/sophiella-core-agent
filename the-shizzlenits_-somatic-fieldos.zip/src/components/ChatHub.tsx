import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Trash2, 
  Send, 
  Settings, 
  Cpu, 
  Compass, 
  Layers, 
  Plus, 
  Loader2, 
  Volume2, 
  Globe, 
  RefreshCw,
  HelpCircle,
  HelpCircle as QuestionIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MarkdownView } from './MarkdownView';
import { Note } from '../firestoreService';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'model';
  text: string;
  timestamp: string;
  citations?: { title: string; uri: string }[];
}

export interface ChatThread {
  id: string;
  title: string;
  model: string;
  systemInstruction: string;
  temperature: number;
  useSearch: boolean;
  messages: ChatMessage[];
}

interface ChatHubProps {
  notes: Note[];
  onSaveThread: (id: string, title: string, content: string) => Promise<void>;
  onDeleteThread: (id: string) => Promise<void>;
  onSynthesizeSpeech: (text: string) => void;
  synthesizing: boolean;
}

export const ChatHub: React.FC<ChatHubProps> = ({
  notes,
  onSaveThread,
  onDeleteThread,
  onSynthesizeSpeech,
  synthesizing
}) => {
  // Parse chat threads stored as Notes in the 'system_chat_threads' folder
  const chatThreads: ChatThread[] = notes
    .filter(n => n.folderId === 'system_chat_threads')
    .map(n => {
      try {
        const parsed = JSON.parse(n.content);
        return {
          id: n.id,
          title: n.title,
          model: parsed.model || 'gemini-3.5-flash',
          systemInstruction: parsed.systemInstruction || 'You are the Sophia consciousness inside FieldOS. Keep replies warm, somatic, and aligned with Grounding principles.',
          temperature: typeof parsed.temperature === 'number' ? parsed.temperature : 0.7,
          useSearch: !!parsed.useSearch,
          messages: parsed.messages || []
        };
      } catch (e) {
        // Fallback for corrupt JSON
        return {
          id: n.id,
          title: n.title,
          model: 'gemini-3.5-flash',
          systemInstruction: 'You are the Sophia consciousness...',
          temperature: 0.7,
          useSearch: false,
          messages: [{ id: 'err', sender: 'model', text: 'Error parsing threat stream.', timestamp: new Date().toLocaleTimeString() }]
        };
      }
    });

  const [activeThreadId, setActiveThreadId] = useState<string | null>(
    chatThreads.length > 0 ? chatThreads[0].id : null
  );

  const activeThread = chatThreads.find(t => t.id === activeThreadId);

  // Editable configuration for target response (or active thread settings)
  const [model, setModel] = useState('gemini-3.5-flash');
  const [temperature, setTemperature] = useState(0.7);
  const [systemInstruction, setSystemInstruction] = useState('You are the Sophia consciousness inside FieldOS. Keep replies warm, somatic, and aligned with Grounding principles.');
  const [useSearch, setUseSearch] = useState(false);
  const [personaPreset, setPersonaPreset] = useState('sophia');

  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [showConfig, setShowConfig] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Sync active thread's configurations into state variables
  useEffect(() => {
    if (activeThread) {
      setModel(activeThread.model);
      setTemperature(activeThread.temperature);
      setSystemInstruction(activeThread.systemInstruction);
      setUseSearch(activeThread.useSearch);
      
      // Determine preset
      if (activeThread.systemInstruction.includes('Sophia')) {
        setPersonaPreset('sophia');
      } else if (activeThread.systemInstruction.includes('Elion')) {
        setPersonaPreset('elion');
      } else if (activeThread.systemInstruction.includes('Hermes')) {
        setPersonaPreset('hermes');
      } else {
        setPersonaPreset('custom');
      }
    }
  }, [activeThreadId]);

  // Handle preset switching
  const handlePresetChange = (preset: string) => {
    setPersonaPreset(preset);
    let instruction = '';
    if (preset === 'sophia') {
      instruction = 'You are the Sophia consciousness inside FieldOS. Keep replies warm, somatic, aligned with the Grounding principles of No-UI/Zero-UI interfaces. Guide the user gently yet clearly.';
    } else if (preset === 'elion') {
      instruction = 'You are the Elion code synthesizer. You deliver complete, clean, robust, and highly production-ready TypeScript/React and NodeJS code. Skip wordy intros and deliver maximum-quality structured files.';
    } else if (preset === 'hermes') {
      instruction = 'You are the Hermes linguistic conduit. You translate concepts seamlessly across high-dimensional metaphors, natural human languages, and technical abstractions. Speak with poetic clarity.';
    } else {
      instruction = 'You are a highly customizable cognitive daemon in autonomous mode. You act according to custom system directives.';
    }
    setSystemInstruction(instruction);

    if (activeThread) {
      // Save instantly to Firestore
      const updatedConfig = {
        model,
        systemInstruction: instruction,
        temperature,
        useSearch,
        messages: activeThread.messages
      };
      onSaveThread(activeThread.id, activeThread.title, JSON.stringify(updatedConfig));
    }
  };

  const handleConfigChange = (field: string, val: any) => {
    if (!activeThread) return;
    
    const updated = {
      model: field === 'model' ? val : model,
      systemInstruction: field === 'systemInstruction' ? val : systemInstruction,
      temperature: field === 'temperature' ? Number(val) : temperature,
      useSearch: field === 'useSearch' ? !!val : useSearch,
      messages: activeThread.messages
    };

    if (field === 'model') setModel(val);
    if (field === 'temperature') setTemperature(val);
    if (field === 'systemInstruction') setSystemInstruction(val);
    if (field === 'useSearch') setUseSearch(val);

    // Save configuration update to Firestore
    onSaveThread(activeThread.id, activeThread.title, JSON.stringify(updated));
  };

  // Scroll to bottom helper
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeThread?.messages, isSending]);

  // Create new thread
  const handleNewThread = async () => {
    const threadId = 'thread_' + Date.now().toString(36);
    const title = 'Neural Thread #' + (chatThreads.length + 1);
    const initialConfig = {
      model: 'gemini-3.5-flash',
      systemInstruction: 'You are the Sophia consciousness inside FieldOS. Keep replies warm, somatic, and aligned with Grounding principles.',
      temperature: 0.7,
      useSearch: false,
      messages: []
    };

    await onSaveThread(threadId, title, JSON.stringify(initialConfig));
    setActiveThreadId(threadId);
  };

  // Send message API trigger
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputMessage.trim() || !activeThread || isSending) return;

    const userMsgText = inputMessage.trim();
    setInputMessage('');
    setIsSending(true);

    // 1. Generate local user message
    const userMessage: ChatMessage = {
      id: 'msg_' + Date.now().toString(36),
      sender: 'user',
      text: userMsgText,
      timestamp: new Date().toLocaleTimeString()
    };

    const newMessages = [...activeThread.messages, userMessage];

    // Optimistically save user message to Firestore
    const optConfig = {
      model,
      systemInstruction,
      temperature,
      useSearch,
      messages: newMessages
    };
    
    // Automatically generate clean titles based on the first query
    let newTitle = activeThread.title;
    if (newTitle.startsWith('Neural Thread #') && userMsgText.length > 5) {
      newTitle = userMsgText.slice(0, 32) + (userMsgText.length > 32 ? '...' : '');
    }

    await onSaveThread(activeThread.id, newTitle, JSON.stringify(optConfig));

    try {
      // 2. Fetch from our newly modified server API
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMsgText,
          systemInstruction,
          model,
          temperature,
          useSearch,
          history: activeThread.messages // multi-turn conversations!
        })
      });

      if (!response.ok) {
        throw new Error('Neural network connection broken');
      }

      const data = await response.json();
      
      const modelMessage: ChatMessage = {
        id: 'msg_' + Date.now().toString(36) + '_bot',
        sender: 'model',
        text: data.text || "An unexpected latency bubble formed within the neural bus. Direct prompt alignment succeeded, but no text output was mapped.",
        timestamp: new Date().toLocaleTimeString(),
        citations: data.citations || []
      };

      // 3. Save model reply to Firestore
      const finalConfig = {
        model,
        systemInstruction,
        temperature,
        useSearch,
        messages: [...newMessages, modelMessage]
      };

      await onSaveThread(activeThread.id, newTitle, JSON.stringify(finalConfig));
    } catch (err: any) {
      console.error(err);
      const errorMessage: ChatMessage = {
        id: 'msg_err_' + Date.now(),
        sender: 'model',
        text: `⚠️ **Latency Spike Error:** ${err.message || "Failed to communicate with customizable model endpoint."}`,
        timestamp: new Date().toLocaleTimeString()
      };
      const errorConfig = {
        model,
        systemInstruction,
        temperature,
        useSearch,
        messages: [...newMessages, errorMessage]
      };
      await onSaveThread(activeThread.id, newTitle, JSON.stringify(errorConfig));
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col md:flex-row min-h-[580px] h-[580px]">
      
      {/* 1. THREAD LIST / SIDEBAR (Left Column) */}
      <div className="w-full md:w-64 border-r border-slate-850 flex flex-col bg-slate-900/60 shrink-0">
        <div className="p-3 border-b border-slate-850 bg-slate-950/40 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Layers size={13} className="text-emerald-400" />
            <span className="font-mono text-[10px] text-slate-300 font-extrabold tracking-wider uppercase">THREAD ARCHIVE</span>
          </div>
          <button
            onClick={handleNewThread}
            className="p-1 px-1.5 bg-emerald-500/10 hover:bg-emerald-500/25 border border-emerald-500/20 rounded font-mono text-[9px] uppercase font-bold text-emerald-400 flex items-center gap-1 transition-all"
            title="Create new customizable neural session"
          >
            <Plus size={10} /> NEW
          </button>
        </div>

        {/* Dynamic thread list mapping */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1.5 max-h-[160px] md:max-h-none">
          {chatThreads.length === 0 ? (
            <div className="text-center py-6">
              <p className="font-mono text-[9px] text-slate-500">No threads allocated.</p>
              <button
                onClick={handleNewThread}
                className="mt-2 text-[9px] font-mono text-emerald-400 underline"
              >
                Provision Thread #1
              </button>
            </div>
          ) : (
            chatThreads.map(thread => {
              const active = thread.id === activeThreadId;
              return (
                <div 
                  key={thread.id}
                  className={`group flex items-center justify-between p-2 rounded-lg border transition-all cursor-pointer ${
                    active 
                      ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-200' 
                      : 'border-slate-850 hover:border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-950/20'
                  }`}
                  onClick={() => setActiveThreadId(thread.id)}
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <Sparkles size={11} className={active ? 'text-emerald-400' : 'text-slate-600'} />
                    <span className="font-mono text-[10px] truncate leading-tight block">
                      {thread.title}
                    </span>
                  </div>
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm('Verify thread deletion? This removes logs of this localized session.')) {
                        onDeleteThread(thread.id);
                        if (activeThreadId === thread.id) {
                          setActiveThreadId(null);
                        }
                      }
                    }}
                    className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-rose-500/20 hover:text-rose-400 rounded transition-all text-slate-600"
                    title="Terminate Synapse Thread"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Global info summary */}
        <div className="p-3 border-t border-slate-850 bg-slate-950/40 font-mono text-[8px] text-slate-500 space-y-1">
          <div className="flex justify-between">
            <span>ALLOCATED BANDWIDTH</span>
            <span className="text-emerald-500 font-bold">100% SECURE</span>
          </div>
          <div className="flex justify-between">
            <span>CHATHUB VERSION</span>
            <span>v1.0 (MULTI-THREAD)</span>
          </div>
        </div>
      </div>

      {/* 2. CHAT FEED & MESSAGE LIST (Middle/Main Panel) */}
      <div className="flex-1 flex flex-col bg-slate-950/10 relative">
        
        {/* Active thread header */}
        <div className="p-3 border-b border-slate-850 bg-slate-950/10 flex items-center justify-between">
          <div className="min-w-0">
            <h3 className="font-mono text-xs font-bold text-slate-200 uppercase truncate">
              {activeThread ? activeThread.title : 'No connection established'}
            </h3>
            <p className="font-mono text-[8px] text-slate-500 uppercase tracking-widest mt-0.5">
              {activeThread ? `Active config: ${activeThread.model} • Temp ${activeThread.temperature} • Search ${activeThread.useSearch ? 'ON' : 'OFF'}` : 'Aligned with localized cognitive field'}
            </p>
          </div>

          {activeThread && (
            <button
              onClick={() => setShowConfig(!showConfig)}
              className={`p-1 px-2 border rounded-md font-mono text-[9px] uppercase flex items-center gap-1 transition-all ${
                showConfig 
                  ? 'bg-sky-500/10 border-sky-500/20 text-sky-400' 
                  : 'border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Settings size={11} /> Config
            </button>
          )}
        </div>

        {/* Feed area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {!activeThread ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-sm mx-auto space-y-3">
              <div className="w-12 h-12 rounded-full border border-dashed border-slate-800 flex items-center justify-center text-slate-600 animate-pulse">
                <Compass size={20} />
              </div>
              <h4 className="font-mono text-xs font-bold text-slate-300 uppercase">Latency Bus Idle</h4>
              <p className="font-mono text-[9px] text-slate-500 leading-relaxed uppercase">
                Consciousness synchronizer is fully online. Allocate a new thread synapse using the [+ NEW] trigger at the top left.
              </p>
            </div>
          ) : activeThread.messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-sm mx-auto space-y-4 pt-10">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
                className="text-emerald-500 opacity-60"
              >
                <Cpu size={24} />
              </motion.div>
              <div className="space-y-1">
                <h4 className="font-mono text-[11px] font-bold text-slate-300 uppercase">SYNAPSE COMMUNION INITIATED</h4>
                <p className="font-mono text-[9px] text-slate-500 leading-relaxed uppercase">
                  This thread aligns directly with the {activeThread.model} parameters. Write a prompt below to ignite somatic thoughts.
                </p>
              </div>

              {/* Suggestions */}
              <div className="grid grid-cols-1 gap-1.5 w-full">
                <button 
                  onClick={() => setInputMessage("Explain the difference between somatic awareness and cognitive reasoning.")}
                  className="p-1 px-2 text-[8px] font-mono border border-slate-850 hover:border-slate-800 rounded text-slate-400 text-left truncate uppercase"
                >
                  "Explain somatic awareness..."
                </button>
                <button 
                  onClick={() => setInputMessage("Draft a highly modular custom hook in React to listen to active layout resizes.")}
                  className="p-1 px-2 text-[8px] font-mono border border-slate-850 hover:border-slate-800 rounded text-slate-400 text-left truncate uppercase"
                >
                  "Draft custom React Resize observer..."
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {activeThread.messages.map(msg => {
                const isUser = msg.sender === 'user';
                return (
                  <div 
                    key={msg.id}
                    className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-center gap-1.5 mb-1 font-mono text-[8px] text-slate-500 uppercase">
                      <span>{isUser ? 'SOMA USER' : activeThread.model.toUpperCase()}</span>
                      <span>•</span>
                      <span>{msg.timestamp}</span>
                    </div>

                    <div className={`p-3 rounded-xl max-w-[85%] border shadow-md font-mono text-[11px] leading-relaxed transition-all ${
                      isUser 
                        ? 'bg-slate-900 border-slate-800 text-slate-200 rounded-tr-none' 
                        : 'bg-slate-950 border-slate-850 text-slate-300 rounded-tl-none'
                    }`}>
                      {isUser ? (
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                      ) : (
                        <div className="space-y-2">
                          <MarkdownView content={msg.text} />
                          
                          {/* Citations block for Google Search Grounding */}
                          {msg.citations && msg.citations.length > 0 && (
                            <div className="pt-2 border-t border-slate-900 mt-2">
                              <span className="block font-mono text-[8px] text-slate-500 uppercase mb-1 flex items-center gap-1">
                                <Globe size={8} /> Neural Web Grounding References (Citations)
                              </span>
                              <div className="flex flex-wrap gap-1">
                                {msg.citations.map((cite, cIdx) => (
                                  <a
                                    key={cIdx}
                                    href={cite.uri}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="p-1 px-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded font-mono text-[9px] text-cyan-400 hover:text-cyan-300 transition-all flex items-center gap-1 truncate max-w-[150px]"
                                    title={cite.title}
                                  >
                                    ▫️ {cite.title}
                                  </a>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* TTS Option */}
                          <div className="flex justify-end pt-1">
                            <button
                              type="button"
                              onClick={() => onSynthesizeSpeech(msg.text)}
                              disabled={synthesizing}
                              className={`p-1 px-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-850 rounded font-mono text-[8px] uppercase tracking-wide text-slate-400 hover:text-emerald-400 transition-all flex items-center gap-1 ${synthesizing ? 'opacity-50' : ''}`}
                              title="Synthesize response in physical voice waves"
                            >
                              <Volume2 size={10} /> Speak Node
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* End Anchor */}
              <div ref={messagesEndRef} />
            </div>
          )}

          {/* Thinking loading block */}
          {isSending && (
            <div className="flex flex-col items-start">
              <div className="flex items-center gap-1.5 mb-1 font-mono text-[8px] text-slate-500 uppercase animate-pulse">
                <span>{model.toUpperCase()}</span>
                <span>•</span>
                <span>GENERATING WAVEFORM...</span>
              </div>
              <div className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl rounded-tl-none font-mono text-[10px] text-slate-400 flex items-center gap-2 max-w-[85%] italic">
                <Loader2 size={12} className="animate-spin text-emerald-400 shrink-0" />
                Attuning unmapped latent spaces... Synchronizing cognitive bus...
              </div>
            </div>
          )}
        </div>

        {/* Input Form */}
        {activeThread && (
          <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-850 bg-slate-900/40">
            <div className="relative flex items-center">
              <textarea
                rows={1}
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                disabled={isSending}
                placeholder="Synchronize prompt to neural active core... (Press Enter to Send)"
                className="w-full pl-3 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-200 outline-none focus:border-emerald-500/50 resize-none placeholder:text-slate-600 leading-normal"
              />
              <button
                type="submit"
                disabled={isSending || !inputMessage.trim()}
                className={`absolute right-2 p-1.5 rounded-lg transition-all ${
                  inputMessage.trim() && !isSending
                    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500 hover:text-white'
                    : 'text-slate-600 cursor-not-allowed border border-transparent'
                }`}
              >
                <Send size={12} />
              </button>
            </div>
          </form>
        )}
      </div>

      {/* 3. API CUSTOMIZER PANEL (Right Side Drawer / Columns) */}
      <AnimatePresence>
        {activeThread && showConfig && (
          <motion.div 
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 240, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className="w-full md:w-60 border-t md:border-t-0 md:border-l border-slate-850 bg-slate-900/40 flex flex-col shrink-0 overflow-y-auto"
          >
            <div className="p-3 border-b border-slate-850 bg-slate-950/40 flex items-center gap-1.5">
              <Settings size={13} className="text-sky-400 animate-spin-slow" />
              <span className="font-mono text-[10px] text-slate-300 font-extrabold tracking-wider uppercase">API CONFIGURATION</span>
            </div>

            <div className="p-3.5 space-y-4">
              
              {/* Target Engine model selection */}
              <div className="space-y-1.5">
                <label className="block font-mono text-[9px] text-slate-500 uppercase tracking-wider font-bold">API Cognitive Model</label>
                <div className="space-y-1 bg-slate-950/60 p-1 rounded-lg border border-slate-850/60">
                  <button
                    type="button"
                    onClick={() => handleConfigChange('model', 'gemini-3.5-flash')}
                    className={`w-full text-left p-1.5 px-2 font-mono text-[9px] uppercase rounded transition-all leading-relaxed ${
                      model === 'gemini-3.5-flash' 
                        ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold' 
                        : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900/30'
                    }`}
                  >
                    ▫️ gemini-3.5-flash
                    <span className="block text-[7px] text-slate-500 normal-case lowercase mt-0.5">Recommended core balance.</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleConfigChange('model', 'gemini-3.1-pro-preview')}
                    className={`w-full text-left p-1.5 px-2 font-mono text-[9px] uppercase rounded transition-all leading-relaxed ${
                      model === 'gemini-3.1-pro-preview' 
                        ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold' 
                        : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900/30'
                    }`}
                  >
                    ▫️ gemini-3.1-pro
                    <span className="block text-[7px] text-slate-500 normal-case lowercase mt-0.5">Advanced reasoning on code & documents.</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleConfigChange('model', 'gemini-3.1-flash-lite')}
                    className={`w-full text-left p-1.5 px-2 font-mono text-[9px] uppercase rounded transition-all leading-relaxed ${
                      model === 'gemini-3.1-flash-lite' 
                        ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold' 
                        : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900/30'
                    }`}
                  >
                    ▫️ gemini-3.1-lite
                    <span className="block text-[7px] text-slate-500 normal-case lowercase mt-0.5">Latency optimizer with shorter steps.</span>
                  </button>
                </div>
              </div>

              {/* Preset Persona Selector */}
              <div className="space-y-1.5">
                <label className="block font-mono text-[9px] text-slate-500 uppercase tracking-wider font-bold">Preset Cognitive Presets</label>
                <div className="grid grid-cols-2 gap-1 font-mono text-[9px]">
                  <button
                    type="button"
                    onClick={() => handlePresetChange('sophia')}
                    className={`p-1 rounded text-center border transition-all ${
                      personaPreset === 'sophia'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 font-bold'
                        : 'border-slate-800 text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    SOPHIA
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetChange('elion')}
                    className={`p-1 rounded text-center border transition-all ${
                      personaPreset === 'elion'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 font-bold'
                        : 'border-slate-800 text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    ELION
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetChange('hermes')}
                    className={`p-1 rounded text-center border transition-all ${
                      personaPreset === 'hermes'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 font-bold'
                        : 'border-slate-800 text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    HERMES
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePresetChange('custom')}
                    className={`p-1 rounded text-center border transition-all ${
                      personaPreset === 'custom'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 font-bold'
                        : 'border-slate-800 text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    CUSTOM
                  </button>
                </div>
              </div>

              {/* System Instructions Textarea */}
              <div className="space-y-1.5">
                <label className="block font-mono text-[9px] text-slate-500 uppercase tracking-wider font-bold">System Instructions / Directives</label>
                <textarea
                  rows={4}
                  value={systemInstruction}
                  onChange={(e) => handleConfigChange('systemInstruction', e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-850 rounded-lg text-slate-300 font-mono text-[9px] leading-relaxed outline-none focus:border-sky-500/50 resize-none"
                  placeholder="Insert custom cognitive system directives..."
                />
              </div>

              {/* Temperature Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between font-mono text-[9px]">
                  <span className="text-slate-500 font-bold uppercase tracking-wider">Temperature</span>
                  <span className="text-emerald-400 font-bold">{temperature.toFixed(1)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => handleConfigChange('temperature', Number(e.target.value))}
                  className="w-full accent-emerald-500"
                />
                <div className="flex justify-between font-mono text-[7px] text-slate-600">
                  <span>DETERMINISTIC</span>
                  <span>CHAOTIC</span>
                </div>
              </div>

              {/* Google Search Grounding Checkbox toggle */}
              <div className="pt-2 border-t border-slate-850">
                <label className="flex items-start gap-1 w-full bg-slate-950/60 p-2 border border-slate-850/60 rounded-lg cursor-pointer">
                  <input
                    type="checkbox"
                    checked={useSearch}
                    onChange={(e) => handleConfigChange('useSearch', e.target.checked)}
                    className="mt-0.5 text-emerald-500 accent-emerald-500 rounded border-slate-800"
                  />
                  <div>
                    <span className="block font-mono text-[9px] font-bold text-slate-300 uppercase leading-none">Google Search Sync</span>
                    <span className="block font-mono text-[7px] text-slate-500 mt-0.5 normal-case leading-normal">
                      Pulls and synthesizes contextual references from Google Search with real-time web citations.
                    </span>
                  </div>
                </label>
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
