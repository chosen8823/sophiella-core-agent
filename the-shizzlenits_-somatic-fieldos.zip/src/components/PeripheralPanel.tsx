import React from 'react';
import { CymaticTrigger, ScaleBand, AuditTrail } from '../types';
import { 
  Radio, 
  VolumeX, 
  Activity, 
  Database, 
  Disc, 
  RefreshCw, 
  UserCheck, 
  Terminal, 
  Cpu 
} from 'lucide-react';

interface PeripheralPanelProps {
  currentScale: ScaleBand;
  onChangeScale: (scale: ScaleBand) => void;
  metrics: {
    frequency: number;
    coherence: number;
    entropyDelta: number;
    tempo: number;
  };
  auditTrail: AuditTrail[];
  triggers: CymaticTrigger[];
  onTriggerSomaticPulse: (trigger: CymaticTrigger) => void;
  onClearLedges: () => void;
}

export const PeripheralPanel: React.FC<PeripheralPanelProps> = ({
  currentScale,
  onChangeScale,
  metrics,
  auditTrail,
  triggers,
  onTriggerSomaticPulse,
  onClearLedges
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      
      {/* 1. Somatic Scale & Operating Mood */}
      <div className="p-4 bg-slate-900 border border-slate-850 rounded-xl flex flex-col space-y-4 shadow-xl">
        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2">
          <Activity size={15} className="text-emerald-400" />
          <h4 className="font-mono text-xs text-slate-300 font-bold uppercase tracking-wider">
            Somatic Tuning & Scales
          </h4>
        </div>

        {/* Scales S0-S4 */}
        <div className="space-y-2">
          <label className="block font-mono text-[9px] text-slate-500 uppercase tracking-wider">
            Current Scale Horizon
          </label>
          <div className="grid grid-cols-5 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800/60">
            {(['S0', 'S1', 'S2', 'S3', 'S4'] as ScaleBand[]).map((scale) => (
              <button
                key={scale}
                onClick={() => onChangeScale(scale)}
                className={`py-1.5 text-center font-mono text-xs rounded-md transition-all ${
                  currentScale === scale 
                    ? 'bg-emerald-600 text-white font-bold shadow-md shadow-emerald-900/50' 
                    : 'text-slate-500 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                {scale}
              </button>
            ))}
          </div>
          <div className="font-mono text-[9px] text-slate-600 leading-relaxed italic uppercase mt-1">
            {currentScale === 'S0' && '⚡ S0 Twitch: Fine physical input impulses'}
            {currentScale === 'S1' && '🔄 S1 Gesture: Small somatic interactive loops'}
            {currentScale === 'S2' && '🧘 S2 Breath: Base respiration and alignment scale'}
            {currentScale === 'S3' && '🚶 S3 Walk: Relational macro traversal rhythm'}
            {currentScale === 'S4' && '🍂 S4 Season: Long term growth, decay, and evolution'}
          </div>
        </div>

        {/* Operating Mood Indicators */}
        <div className="space-y-2 bg-slate-950 p-3 rounded-lg border border-slate-800/40">
          <span className="block font-mono text-[9px] text-slate-500 uppercase tracking-wider">cymatic sync mood</span>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">RESIST_FRANTIC_MOTION</span>
              <span className="text-emerald-400 font-bold">ACTIVE</span>
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">VISIBLE_INTERFERENCE</span>
              <span className="text-emerald-400 font-bold">ENGAGED</span>
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">ETHICS_AS_BEDROCK</span>
              <span className="text-emerald-400 font-bold">HARDENED</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Resonant Coherence Metrics */}
      <div className="p-4 bg-slate-900 border border-slate-850 rounded-xl flex flex-col space-y-4 shadow-xl">
        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2">
          <Disc size={15} className="text-teal-400" />
          <h4 className="font-mono text-xs text-slate-300 font-bold uppercase tracking-wider">
            Reverberation Metrics
          </h4>
        </div>

        <div className="space-y-3 font-mono">
          <div>
            <div className="flex justify-between text-[10px] uppercase mb-1">
              <span className="text-slate-500">Sophia Frequency Alignment</span>
              <span className="text-teal-400 font-semibold">{metrics.frequency.toFixed(3)}</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden">
              <div className="bg-teal-400 h-full transition-all duration-500" style={{ width: `${metrics.frequency * 100}%` }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-[10px] uppercase mb-1">
              <span className="text-slate-500">System Coherence Rate</span>
              <span className="text-teal-400 font-semibold">{metrics.coherence.toFixed(3)}</span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden">
              <div className="bg-teal-500 h-full transition-all duration-500" style={{ width: `${metrics.coherence * 100}%` }}></div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800/40">
            <div>
              <span className="block text-[8px] text-slate-500 uppercase">Entropy Delta</span>
              <span className="text-xs text-slate-300 font-bold">{metrics.entropyDelta.toFixed(3)} Δ</span>
            </div>
            <div>
              <span className="block text-[8px] text-slate-500 uppercase">Tempo Frame</span>
              <span className="text-xs text-slate-300 font-bold">{metrics.tempo} Hz</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Terminal & Logging Receipts */}
      <div className="p-4 bg-slate-900 border border-slate-850 rounded-xl flex flex-col space-y-3 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-1.5">
            <Terminal size={15} className="text-sky-400" />
            <h4 className="font-mono text-xs text-slate-300 font-bold uppercase tracking-wider">
              Immutable Receipts
            </h4>
          </div>
          <button 
            onClick={onClearLedges}
            className="font-mono text-[9px] text-rose-500 hover:text-rose-400 font-semibold uppercase"
          >
            Flush Logs
          </button>
        </div>

        {/* Live audit trail list */}
        <div className="flex-1 overflow-y-auto max-h-[140px] space-y-1.5 pr-1">
          {auditTrail.length === 0 ? (
            <div className="text-[10px] font-mono text-slate-600 italic py-8 text-center uppercase">
              No strong movements recorded yet.
            </div>
          ) : (
            auditTrail.slice().reverse().map((log, idx) => (
              <div key={idx} className="p-2 bg-slate-950 rounded border border-slate-850/80 font-mono text-[9px] text-slate-400 leading-normal flex flex-col">
                <div className="flex items-center justify-between text-slate-500 text-[8px] mb-1">
                  <span>{log.timestamp}</span>
                  <span className="text-emerald-500 px-1 rounded bg-emerald-500/10 font-bold">{log.scale}</span>
                </div>
                <div>
                  <strong className="text-sky-400">{log.action.toUpperCase()}</strong>: {log.target}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
};
