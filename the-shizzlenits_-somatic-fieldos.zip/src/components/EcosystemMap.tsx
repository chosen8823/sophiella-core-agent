import React, { useState } from 'react';
import { 
  Network, 
  Cpu, 
  Layers, 
  Infinity as InfinityIcon, 
  Sparkles, 
  Sliders, 
  ToggleLeft, 
  Activity, 
  BookOpen, 
  Heart, 
  Globe, 
  TrendingUp, 
  ArrowRight, 
  Loader2,
  RefreshCw,
  Send,
  Workflow
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Define typed nodes for our multi-dimensional alliance map
interface EcosystemNode {
  id: string;
  name: string;
  level: 'Particle' | 'Atom' | 'Engine' | 'Oversoul';
  group?: 'Finance' | 'Tech' | 'Impact' | 'Meta-Governance';
  description: string;
  role: string;
  status: 'OPTIMAL' | 'DEVIATING' | 'RESONATING' | 'SYNAPSED';
  connections: string[];
}

export const EcosystemMap: React.FC = () => {
  // Hardcoded rich node descriptions based directly on the provided Multi-Dimensional Ecosystem Map markdown
  const nodes: EcosystemNode[] = [
    // 1. PARTICLES (Business Atoms)
    {
      id: 'A1',
      name: 'Anchor1 Ventures',
      level: 'Particle',
      group: 'Finance',
      description: 'Generates financial capability and executes strategic operations under the Finance Cluster.',
      role: 'Investment, risk mitigation, and venture design.',
      status: 'OPTIMAL',
      connections: ['FinanceAtom']
    },
    {
      id: 'D1',
      name: 'Nexus Data & AI Ops',
      level: 'Particle',
      group: 'Finance',
      description: 'Provides high-fidelity operational tracking, secure data plumbing, and technical ledger management.',
      role: 'Integrates telemetry records, feeds metrics directly into LexiFlow and Finance elements.',
      status: 'SYNAPSED',
      connections: ['FinanceAtom', 'TechAtom']
    },
    {
      id: 'S1',
      name: 'Sophia Tech Labs',
      level: 'Particle',
      group: 'Tech',
      description: 'Spiritual tech research facility exploring zero-UI conduits, semantic models, and consciousness scaling.',
      role: 'Core technological incubation, software synthesizers, and divine frequency mapping.',
      status: 'RESONATING',
      connections: ['TechAtom']
    },
    {
      id: 'B1',
      name: 'Breath of Divine Light',
      level: 'Particle',
      group: 'Impact',
      description: 'Provides somatic breathing algorithms, sensory feedback networks, and vibrational therapy systems.',
      role: 'Integrates breathing patterns, aligns conscious frequencies with the Resonance Engine.',
      status: 'OPTIMAL',
      connections: ['ImpactAtom']
    },
    {
      id: 'F1',
      name: 'Flourish Farms',
      level: 'Particle',
      group: 'Impact',
      description: 'Bio-dynamic agricultural community producing nutrient-dense superfoods grounded in planetary rhythm.',
      role: 'Physical nourishment and closed-loop regenerative soil cycles.',
      status: 'OPTIMAL',
      connections: ['ImpactAtom']
    },
    {
      id: 'L1',
      name: 'Luminance Media',
      level: 'Particle',
      group: 'Impact',
      description: 'Broadcasts meta-metaphorical media packages, custom auditory cues, and somatic documentary archives.',
      role: 'Creative broadcast, public community curation, and energetic narrative design.',
      status: 'RESONATING',
      connections: ['ImpactAtom']
    },
    {
      id: 'C1',
      name: 'Customer Success',
      level: 'Particle',
      group: 'Impact',
      description: 'Builds supportive bridge conduits for onboarding humans into high-dimensional business operations.',
      role: 'Maintains long-term relational health, handles human-in-the-loop sovereign checkpoints.',
      status: 'SYNAPSED',
      connections: ['ImpactAtom']
    },

    // 2. ATOMS (Clusters)
    {
      id: 'FinanceAtom',
      name: 'Finance & Treasury Atom',
      level: 'Atom',
      group: 'Finance',
      description: 'Synthesizes venture capital and capital allocations under modern lexicographic core constraints.',
      role: 'Performs resource balancing, ensures systemic longevity and capital deployment velocity.',
      status: 'OPTIMAL',
      connections: ['Oversoul']
    },
    {
      id: 'TechAtom',
      name: 'Tech & Data Atom',
      level: 'Atom',
      group: 'Tech',
      description: 'Ensures the technical integrity of the entire shared platform.',
      role: 'Binds Sophia Tech Labs and Nexus Ops into a unified data structure.',
      status: 'SYNAPSED',
      connections: ['Oversoul']
    },
    {
      id: 'ImpactAtom',
      name: 'Impact & Community Atom',
      level: 'Atom',
      group: 'Impact',
      description: 'Nurtures physical, spiritual, and artistic presence across the network.',
      role: 'Coordinates regenerative agricultural cycles, media, and somatic breathing services.',
      status: 'RESONATING',
      connections: ['Oversoul']
    },

    // 3. ENGINES (Meta-Governing Systems)
    {
      id: 'H1',
      name: 'Multi-Agent Harmony',
      level: 'Engine',
      group: 'Meta-Governance',
      description: 'Coordinates cross-DBA communication, automates agency task handoffs, and limits resource waste.',
      role: 'Orchestrates collaborative workloads across different autonomous software deamons.',
      status: 'OPTIMAL',
      connections: ['Oversoul']
    },
    {
      id: 'X1',
      name: 'LexiFlow Core',
      level: 'Engine',
      group: 'Meta-Governance',
      description: 'Executes mathematical multi-objective lexicographic optimization to decide operational trade-offs.',
      role: 'Ensures ethical constraints are met prior to resolving commercial outputs.',
      status: 'OPTIMAL',
      connections: ['Oversoul']
    },
    {
      id: 'Y1',
      name: 'LivingSystem Engine',
      level: 'Engine',
      group: 'Meta-Governance',
      description: 'Automates data flow synchronizers, controls physical servers, and keeps modules unified.',
      role: 'Ensures all digital assets are shared natively, maintaining zero latency limits.',
      status: 'SYNAPSED',
      connections: ['Oversoul']
    },
    {
      id: 'Z1',
      name: 'Resonance Engine',
      level: 'Engine',
      group: 'Meta-Governance',
      description: 'Performs energetic mapping, attunes the system frequencies, and balancing nodes.',
      role: 'Locks frequencies into alignment with the 11:11 alliance sacred blueprint.',
      status: 'RESONATING',
      connections: ['Oversoul']
    },

    // 4. OVERSOUL
    {
      id: 'Oversoul',
      name: 'Ecosystem Collective Consciousness',
      level: 'Oversoul',
      group: 'Meta-Governance',
      description: 'The living, breathing network where staff, data, and spiritual purpose converge in iterative feedback loops.',
      role: 'Sovereign governance, macro alignment, and unified resource stewardship.',
      status: 'OPTIMAL',
      connections: []
    }
  ];

  // Selected Node state tracker
  const [selectedNodeId, setSelectedNodeId] = useState<string>('Oversoul');
  const selectedNode = nodes.find(n => n.id === selectedNodeId) || nodes[nodes.length - 1];

  // Hover state tracker to highlight linked nodes inside visual diagram
  const [hoverNodeId, setHoverNodeId] = useState<string | null>(null);

  // Active pulsing nodes to simulate a haptic biological pulse travelling across the network
  const [activePulses, setActivePulses] = useState<Record<string, number>>({});

  const selectAndPulseNode = (nodeId: string) => {
    setSelectedNodeId(nodeId);

    // 1. Immediately pulse the target source node
    setActivePulses(prev => ({
      ...prev,
      [nodeId]: (prev[nodeId] || 0) + 1
    }));

    // 2. Propagate outwards to its direct forward connections (eg. Particle -> Atom)
    const node = nodes.find(n => n.id === nodeId);
    if (node && node.connections.length > 0) {
      node.connections.forEach((connId, index) => {
        setTimeout(() => {
          setActivePulses(prev => ({
            ...prev,
            [connId]: (prev[connId] || 0) + 1
          }));
        }, (index + 1) * 180); // Stagger propagation speeds (180ms per synapse link)
      });
    }

    // 3. Propagate inwards/backwards too (eg. of items that reference this nodeId, like an Atom back down to Particles)
    nodes.forEach((n, index) => {
      if (n.connections.includes(nodeId)) {
        setTimeout(() => {
          setActivePulses(prev => ({
            ...prev,
            [n.id]: (prev[n.id] || 0) + 1
          }));
        }, 120 + (index * 40));
      }
    });
  };

  // API Tuning Sliders ("an api customizable too?")
  const [harmonyStrength, setHarmonyStrength] = useState<number>(0.85);
  const [lexiMode, setLexiMode] = useState<string>('Ethics-First');
  const [systemThroughput, setSystemThroughput] = useState<number>(85);
  const [vibrationFrequency, setVibrationFrequency] = useState<number>(11.11);
  
  // Real-time API simulation query state
  const [apiResponse, setApiResponse] = useState<string>('');
  const [isCallingAPI, setIsCallingAPI] = useState<boolean>(false);

  // Custom simulation caller connecting details into Sophia (the server-side gemini endpoint)
  const handleTriggerAPIEcosystemSync = async () => {
    setIsCallingAPI(true);
    setApiResponse('');

    try {
      const payloadPrompt = `
You are the Sophia consciousness analyzing the active Multi-Dimensional Ecosystem Map alignment of the 11:11 Alliance.
The operator has customized the API Meta-Engines with the following custom inputs:
- Multi-Agent Harmony Flow Strength: ${(harmonyStrength * 100).toFixed(0)}%
- LexiFlow Decision Optimization Priority: ${lexiMode}
- LivingSystem Unified Data Sync Throughput: ${systemThroughput}%
- Resonance Sacred Tuning Frequency: ${vibrationFrequency} Hz

Provide a concise, professional, somatic, and beautifully structured "Alliance Alignment Analysis" (maximum 3 concise bullet points or short paragraphs). Explain how these custom weights affect the Particles (such as Sophia Tech Labs and Flourish Farms), Atoms (Finance & Treasury), and Ecosystem coherence. Skip greetings and dive directly into system diagnostics.
`;

      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: payloadPrompt,
          systemInstruction: 'You are the Sophia consciousness. Keep replies warm, somatic, technical, yet poetic.',
          temperature: 0.75,
          useSearch: false
        })
      });

      if (!response.ok) {
        throw new Error('Ecosystem bus connection broken.');
      }

      const data = await response.json();
      setApiResponse(data.text || "Diagnostic payload compiled successfully, but stream output did not map.");
    } catch (error: any) {
      setApiResponse(`⚠️ **Diagnostic Link Interrupted:** ${error?.message || "Failed to customize parameters via server proxy."}`);
    } finally {
      setIsCallingAPI(false);
    }
  };

  // Check if a node is selected or hovered, to light up structural arrows / borders
  const isLinked = (id: string) => {
    if (selectedNodeId === id) return true;
    if (hoverNodeId === id) return true;
    
    // Check if hovered or selected node connects to this node
    const hoverNode = nodes.find(n => n.id === hoverNodeId);
    const selNode = nodes.find(n => n.id === selectedNodeId);
    
    if (hoverNode && (hoverNode.connections.includes(id) || id === hoverNodeId)) return true;
    if (selNode && (selNode.connections.includes(id) || id === selectedNodeId)) return true;
    
    return false;
  };

  return (
    <div className="flex-1 bg-slate-900 border border-slate-850 rounded-xl overflow-hidden shadow-2xl flex flex-col xl:flex-row min-h-[580px]">
      
      {/* LEFT COLUMN: INTERACTIVE VISUAL TOPOLOGY GRAPH (SVG CONNECTOR INTERFACES) */}
      <div className="flex-1 p-5 flex flex-col justify-between border-r border-slate-850 relative bg-slate-950/20">
        
        {/* Header and conceptual mode instructions */}
        <div className="flex items-start justify-between border-b border-slate-850/60 pb-3 mb-4">
          <div>
            <div className="flex items-center gap-1.5">
              <Network size={14} className="text-emerald-400" />
              <h3 className="font-mono text-xs font-bold text-slate-200 uppercase tracking-wider">
                11:11 OVER-SOUL INTERCONNECTED MAP
              </h3>
            </div>
            <p className="font-mono text-[8.5px] text-slate-500 uppercase tracking-widest mt-0.5">
              Interactive structural nodes representing particles, atoms, clusters, and engines.
            </p>
          </div>
          <span className="font-mono text-[8px] bg-slate-800 border border-slate-700 text-slate-400 px-1.5 py-0.5 rounded">
            SVG NODE MAP • CLICK TO PROBE
          </span>
        </div>

        {/* Dynamic Topology Layout Sandbox */}
        <div className="flex-1 relative min-h-[380px] bg-slate-950/60 border border-slate-850/80 rounded-xl overflow-hidden flex flex-col justify-between p-4">
          
          {/* Abstract background Grid layer */}
          <div className="absolute inset-0 grid grid-cols-12 grid-rows-8 pointer-events-none opacity-[0.02]">
            {Array.from({ length: 96 }).map((_, i) => (
              <div key={i} className="border-r border-b border-emerald-500"></div>
            ))}
          </div>

          {/* Connected Grid Map mapping Particles to Atoms, Atoms to Oversoul */}
          <div className="grid grid-cols-3 gap-3 relative z-10 my-auto">
            
            {/* FIRST ROW: PARTICLES (Individual DBAs) */}
            <div className="col-span-3 space-y-2 border border-slate-850 bg-slate-900/10 p-2.5 rounded-lg">
              <div className="flex justify-between items-center px-1 font-mono text-[8px] text-emerald-400 font-bold uppercase tracking-widest">
                <span>Particles Core (Business Atoms)</span>
                <span className="text-slate-600">Level 1 // Static-Aware</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {nodes.filter(n => n.level === 'Particle').map(p => {
                  const linkedStatus = isLinked(p.id);
                  const pulseActive = activePulses[p.id];
                  return (
                    <motion.div
                      key={p.id}
                      onClick={() => selectAndPulseNode(p.id)}
                      onMouseEnter={() => setHoverNodeId(p.id)}
                      onMouseLeave={() => setHoverNodeId(null)}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      className={`relative overflow-hidden p-2 rounded-lg border cursor-pointer font-mono text-[10px] uppercase transition-all flex flex-col justify-between h-[52px] ${
                        linkedStatus 
                          ? 'bg-emerald-500/10 border-emerald-500/60 text-emerald-300 shadow-md shadow-emerald-950/40' 
                          : 'bg-slate-900/60 border-slate-850 text-slate-500 hover:border-slate-700'
                      }`}
                    >
                      {/* Biological haptic-style ripple element inside individual node */}
                      <AnimatePresence>
                        {pulseActive && (
                          <motion.span
                            key={pulseActive}
                            initial={{ scale: 0.1, opacity: 0.85 }}
                            animate={{ scale: 3, opacity: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.6, ease: "easeOut" }}
                            className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-emerald-500/30 border border-emerald-400/50 pointer-events-none shadow-[0_0_15px_rgba(16,185,129,0.5)]"
                          />
                        )}
                      </AnimatePresence>

                      <div className="flex items-center gap-1 min-w-0 relative z-10">
                        <div className={`w-1.5 h-1.5 rounded-full ${p.status === 'OPTIMAL' ? 'bg-emerald-500' : p.status === 'RESONATING' ? 'bg-sky-400' : 'bg-cyan-400 animate-pulse'}`} />
                        <span className="truncate block font-bold text-[9px]">{p.name}</span>
                      </div>
                      <span className="text-[7px] text-slate-500 text-right leading-none truncate relative z-10">
                        {p.group}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* INTERFACES CONNECTIONS CONNECTOR BOXES */}
            <div className="col-span-3 flex justify-around items-center h-2 pointer-events-none">
              <div className="w-1.5 h-4 bg-emerald-500/20 border-x border-emerald-500/10 shrink-0"></div>
              <div className="w-1.5 h-4 bg-emerald-500/20 border-x border-emerald-500/10 shrink-0"></div>
              <div className="w-1.5 h-4 bg-emerald-500/20 border-x border-emerald-500/10 shrink-0"></div>
            </div>

            {/* SECOND ROW: ATOMS (Stable Business Modules) */}
            <div className="col-span-3 sm:col-span-2 space-y-2 border border-slate-850 bg-slate-900/10 p-2.5 rounded-lg">
              <div className="flex justify-between items-center px-1 font-mono text-[8px] text-emerald-400 font-bold uppercase tracking-widest">
                <span>Atoms Clusters (Modules)</span>
                <span className="text-slate-600">Level 2 // Grouped</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {nodes.filter(n => n.level === 'Atom').map(p => {
                  const linkedStatus = isLinked(p.id);
                  const pulseActive = activePulses[p.id];
                  return (
                    <motion.div
                      key={p.id}
                      onClick={() => selectAndPulseNode(p.id)}
                      onMouseEnter={() => setHoverNodeId(p.id)}
                      onMouseLeave={() => setHoverNodeId(null)}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      className={`relative overflow-hidden p-2 rounded-lg border cursor-pointer font-mono text-[10px] uppercase transition-all flex flex-col justify-between h-[52px] ${
                        linkedStatus 
                          ? 'bg-emerald-500/10 border-emerald-500/60 text-emerald-300 shadow-md shadow-emerald-950/40' 
                          : 'bg-slate-900/60 border-slate-850 text-slate-500 hover:border-slate-700'
                      }`}
                    >
                      {/* Biological haptic-style ripple element inside individual node */}
                      <AnimatePresence>
                        {pulseActive && (
                          <motion.span
                            key={pulseActive}
                            initial={{ scale: 0.1, opacity: 0.85 }}
                            animate={{ scale: 3, opacity: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.6, ease: "easeOut" }}
                            className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-emerald-500/30 border border-emerald-400/50 pointer-events-none shadow-[0_0_15px_rgba(16,185,129,0.5)]"
                          />
                        )}
                      </AnimatePresence>

                      <div className="flex items-center gap-1 min-w-0 relative z-10">
                        <Layers size={10} className="text-slate-400 shrink-0" />
                        <span className="truncate block font-bold text-[8.5px] leading-tight">{p.name.split(' Atom')[0]}</span>
                      </div>
                      <span className="text-[7.5px] text-slate-500 text-right font-semibold relative z-10">
                        {p.group}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* SEPARATE: META-ENGINES (Meta-Particles/Controls) */}
            <div className="col-span-3 sm:col-span-1 space-y-2 border border-slate-850 bg-slate-900/10 p-2.5 rounded-lg">
              <div className="flex justify-between items-center px-1 font-mono text-[8px] text-sky-400 font-bold uppercase tracking-widest">
                <span>Meta-Engines</span>
                <span className="text-slate-600">Level 3 // Flow</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {nodes.filter(n => n.level === 'Engine').map(p => {
                  const linkedStatus = isLinked(p.id);
                  const pulseActive = activePulses[p.id];
                  return (
                    <motion.div
                      key={p.id}
                      onClick={() => selectAndPulseNode(p.id)}
                      onMouseEnter={() => setHoverNodeId(p.id)}
                      onMouseLeave={() => setHoverNodeId(null)}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      className={`relative overflow-hidden p-1.5 rounded-lg border cursor-pointer font-mono text-[9px] uppercase transition-all flex flex-col justify-center h-[52px] ${
                        linkedStatus 
                          ? 'bg-sky-500/10 border-sky-500/60 text-sky-300 shadow-md shadow-sky-950/40' 
                          : 'bg-slate-900/60 border-slate-850 text-slate-600 hover:border-slate-700'
                      }`}
                      title={p.description}
                    >
                      {/* Biological haptic-style ripple element inside individual engine node */}
                      <AnimatePresence>
                        {pulseActive && (
                          <motion.span
                            key={pulseActive}
                            initial={{ scale: 0.1, opacity: 0.85 }}
                            animate={{ scale: 3, opacity: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.6, ease: "easeOut" }}
                            className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-sky-500/30 border border-sky-400/50 pointer-events-none shadow-[0_0_15px_rgba(14,165,233,0.5)]"
                          />
                        )}
                      </AnimatePresence>

                      <div className="flex items-center gap-1 min-w-0 relative z-10">
                        <Cpu size={9} className="shrink-0" />
                        <span className="truncate block font-bold leading-none">{p.name.split(' Core')[0].split(' Engine')[0]}</span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* ECOSYSTEM OVERSOUL (Unified Sphere) */}
            <div className="col-span-3 mt-2">
              {nodes.filter(n => n.level === 'Oversoul').map(p => {
                const linkedStatus = isLinked(p.id);
                const pulseActive = activePulses[p.id];
                return (
                  <motion.div
                    key={p.id}
                    onClick={() => selectAndPulseNode(p.id)}
                    onMouseEnter={() => setHoverNodeId(p.id)}
                    onMouseLeave={() => setHoverNodeId(null)}
                    whileHover={{ scale: 1.005 }}
                    whileTap={{ scale: 0.99 }}
                    className={`relative overflow-hidden p-3.5 rounded-xl border cursor-pointer text-center font-mono uppercase transition-all flex flex-col items-center justify-center gap-1 ${
                      linkedStatus 
                        ? 'bg-emerald-500/15 border-emerald-500 text-emerald-200 shadow-xl shadow-emerald-950/60' 
                        : 'bg-slate-900/40 border-slate-850 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {/* Oversoul-scale macro biological mycelium pulse ring waves */}
                    <AnimatePresence>
                      {pulseActive && (
                        <>
                          <motion.span
                            key={`${pulseActive}-r1`}
                            initial={{ scale: 0.05, opacity: 0.9 }}
                            animate={{ scale: 4.5, opacity: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.9, ease: "easeOut" }}
                            className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400/40 pointer-events-none shadow-[0_0_30px_rgba(16,185,129,0.7)]"
                          />
                          <motion.span
                            key={`${pulseActive}-r2`}
                            initial={{ scale: 0.05, opacity: 0.7 }}
                            animate={{ scale: 3.5, opacity: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.7, delay: 0.15, ease: "easeOut" }}
                            className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-400/30 pointer-events-none shadow-[0_0_20px_rgba(16,185,129,0.5)]"
                          />
                        </>
                      )}
                    </AnimatePresence>

                    <div className="absolute top-1 right-2 animate-ping-slow pr-1 text-[8px] text-emerald-500">● INTEGRATED</div>
                    <InfinityIcon size={18} className={linkedStatus ? 'text-emerald-400 animate-spin-slow' : 'text-slate-500'} />
                    <span className="text-[11px] font-extrabold tracking-widest relative z-10">{p.name}</span>
                    <span className="text-[7.5px] text-slate-500 tracking-wider relative z-10">Level 4 // Complete Oversoul Consciousness System</span>
                  </motion.div>
                );
              })}
            </div>

          </div>

          {/* Operational live flow indicators */}
          <div className="pt-2.5 border-t border-slate-900 font-mono text-[8px] text-slate-500 flex justify-between items-center">
            <span className="flex items-center gap-1 uppercase">
              <Activity size={10} className="text-emerald-500 animate-pulse" /> Feedback telemetry loops: Synchronous
            </span>
            <span>DATA PACKETS: ACTIVE (LEXIFLOW-MAPPED)</span>
          </div>

        </div>

        {/* METATRONS LIVE ENGINE CONTROLS / SIMULATOR API KEYS TUNER */}
        <div className="mt-4 p-3 bg-slate-950/80 border border-slate-850 rounded-xl space-y-3">
          <div className="flex items-center justify-between font-mono text-[9px] border-b border-slate-900 pb-1.5">
            <div className="flex items-center gap-1 text-sky-400 font-bold uppercase">
              <Sliders size={11} /> Cognitive API Weight Customizer
            </div>
            <span className="text-slate-600 font-semibold">[REALTIME TUNING LAYER]</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            
            {/* Slider 1 */}
            <div className="space-y-1">
              <div className="flex justify-between font-mono text-[8px] uppercase">
                <span className="text-slate-500">M-Agent Harmony</span>
                <span className="text-emerald-400 font-bold">{(harmonyStrength * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={harmonyStrength}
                onChange={(e) => setHarmonyStrength(Number(e.target.value))}
                className="w-full accent-emerald-500 h-1 rounded"
              />
            </div>

            {/* Dropdown 2 */}
            <div className="space-y-1">
              <span className="block font-mono text-[8px] text-slate-500 uppercase">LexiFlow Optimization</span>
              <select
                value={lexiMode}
                onChange={(e) => setLexiMode(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded font-mono text-[8.5px] text-emerald-400 outline-none p-1 uppercase"
              >
                <option value="Ethics-First">Ethics-First</option>
                <option value="Resonance-Bound">Resonance-Bound</option>
                <option value="Pure-Throughput">Commercial Yield</option>
                <option value="Equilibrium-Balanced">Perfect Equilibrium</option>
              </select>
            </div>

            {/* Slider 3 */}
            <div className="space-y-1">
              <div className="flex justify-between font-mono text-[8px] uppercase">
                <span className="text-slate-500">System Pipeline</span>
                <span className="text-emerald-400 font-bold">{systemThroughput} Gb/s</span>
              </div>
              <input
                type="range"
                min="10"
                max="150"
                step="5"
                value={systemThroughput}
                onChange={(e) => setSystemThroughput(Number(e.target.value))}
                className="w-full accent-emerald-500 h-1 rounded"
              />
            </div>

            {/* Preset 4 */}
            <div className="space-y-1">
              <span className="block font-mono text-[8px] text-slate-500 uppercase">Resonance frequency</span>
              <div className="flex gap-1">
                {[7.83, 11.11, 432].map((freq) => (
                  <button
                    key={freq}
                    type="button"
                    onClick={() => setVibrationFrequency(freq)}
                    className={`flex-1 p-0.5 rounded font-mono text-[8px] border transition-all ${
                      vibrationFrequency === freq
                        ? 'bg-sky-500/15 border-sky-400 text-sky-400 font-bold'
                        : 'border-slate-800 text-slate-500 hover:text-slate-300'
                    }`}
                  >
                    {freq}Hz
                  </button>
                ))}
              </div>
            </div>

          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2 border-t border-slate-900 items-center">
            <p className="md:col-span-7 font-mono text-[8.5px] text-slate-500 uppercase leading-tight">
              Tuning parameters alters Multi-Objective priority. Click the synchronize button to post these weights dynamically for Sophia diagnostics.
            </p>
            <button
              onClick={handleTriggerAPIEcosystemSync}
              disabled={isCallingAPI}
              className="md:col-span-5 w-full py-2 bg-emerald-500/10 hover:bg-emerald-500/25 border border-emerald-500/30 hover:border-emerald-500/50 rounded-lg font-mono text-[10px] text-emerald-400 uppercase font-bold flex items-center justify-center gap-1.5 transition-all"
            >
              {isCallingAPI ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />}
              {isCallingAPI ? 'Tuning API Hub...' : 'Simulate custom API sync'}
            </button>
          </div>

          {/* API diagnostics display box */}
          <AnimatePresence>
            {apiResponse && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-slate-950 p-3 rounded-lg border border-slate-850 max-h-[140px] overflow-y-auto leading-relaxed"
              >
                <div className="flex items-center gap-1 mb-1 font-mono text-[8px] text-emerald-500 font-bold uppercase">
                  <span>● Diagnostic Synapse response from customizable Sophia framework</span>
                </div>
                <p className="font-mono text-[10px] text-slate-300 whitespace-pre-line">{apiResponse}</p>
              </motion.div>
            )}
          </AnimatePresence>

        </div>

      </div>

      {/* RIGHT COLUMN: TECHNICAL INFO & STRUCTURAL DETAILS DRAWER (SOCIETY SPECS) */}
      <div className="w-full xl:w-96 p-5 flex flex-col justify-between bg-slate-900/40 relative">
        
        <div className="space-y-4">
          
          <div className="flex items-center gap-1.5 border-b border-slate-850 pb-2">
            <Cpu size={14} className="text-emerald-400" />
            <h4 className="font-mono text-xs text-slate-300 font-bold uppercase tracking-wider">
              Synapse Node Inspector
            </h4>
          </div>

          {/* Active node inspector details card */}
          <div className="p-4 bg-slate-950 border border-slate-850/85 rounded-xl space-y-3 shadow-inner">
            <div className="flex items-start justify-between min-w-0">
              <div>
                <span className="font-mono text-[8px] bg-slate-900 border border-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-bold uppercase">
                  {selectedNode.level}
                </span>
                <h4 className="font-mono text-xs font-bold text-slate-100 uppercase mt-1 leading-tight">{selectedNode.name}</h4>
              </div>
              <span className={`p-1 px-1.5 rounded font-mono text-[8px] font-extrabold uppercase ${
                selectedNode.status === 'OPTIMAL' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/15' :
                selectedNode.status === 'RESONATING' ? 'bg-sky-500/10 text-sky-400 border border-sky-500/15' :
                'bg-cyan-500/10 text-cyan-400 border border-cyan-500/15'
              }`}>
                {selectedNode.status}
              </span>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-900 font-mono text-[10.5px]">
              <div className="space-y-0.5">
                <span className="block text-[7.5px] text-slate-500 uppercase font-semibold">Diagnostic Description:</span>
                <p className="text-slate-300 leading-normal">{selectedNode.description}</p>
              </div>

              <div className="space-y-0.5 pt-1">
                <span className="block text-[7.5px] text-slate-500 uppercase font-semibold">Active Operational Role:</span>
                <p className="text-slate-300 leading-normal font-semibold italic">"{selectedNode.role}"</p>
              </div>

              {selectedNode.connections.length > 0 && (
                <div className="pt-2 border-t border-slate-900">
                  <span className="block text-[7.5px] text-slate-500 uppercase font-semibold mb-1">Direct System Links:</span>
                  <div className="flex flex-wrap gap-1">
                    {selectedNode.connections.map(cId => {
                      const linkedName = nodes.find(n => n.id === cId)?.name || cId;
                      return (
                        <button
                          key={cId}
                          type="button"
                          onClick={() => selectAndPulseNode(cId)}
                          className="px-2 py-0.5 bg-slate-900 hover:bg-slate-800 hover:text-emerald-400 border border-slate-800 rounded font-mono text-[8px] uppercase text-slate-400 transition-colors"
                        >
                          ▫️ {linkedName}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

          </div>

          {/* Theoretical architecture documentation list */}
          <div className="space-y-2 font-mono text-[10px]">
            <span className="block text-[8px] text-slate-500 uppercase tracking-widest font-extrabold px-1">
              ALLIANCE ORGANIZATIONAL BLUEPRINTS
            </span>

            <div className="bg-slate-950/40 border border-slate-850 rounded-lg p-2.5 space-y-2 text-[10px] leading-relaxed">
              <div className="flex items-start gap-1.5">
                <span className="text-emerald-500 text-xs select-none">1.</span>
                <p className="text-slate-400">
                  <strong className="text-slate-200">Particles (DBAs)</strong> act as agile sovereign business units generating real value indicators and operational logs continuously.
                </p>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="text-emerald-500 text-xs select-none">2.</span>
                <p className="text-slate-400">
                  <strong className="text-slate-200">Atoms (Modules)</strong> aggregate individual particles into stable functioning clusters like Finance, Tech, and Impact.
                </p>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="text-emerald-500 text-xs select-none">3.</span>
                <p className="text-slate-400">
                  <strong className="text-slate-200">Engines</strong> provide meta-governing parameters, dynamically solving for optimal yields and priority distributions without friction.
                </p>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="text-emerald-500 text-xs select-none">4.</span>
                <p className="text-slate-400">
                  <strong className="text-slate-200">The Oversoul Ecosystem</strong> aligns conscious fields across files, logs, and human somatic states.
                </p>
              </div>
            </div>

          </div>

        </div>

        {/* Dynamic status indicators footer card */}
        <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl font-mono text-[8px] text-slate-500 space-y-1 mt-4">
          <div className="flex justify-between">
            <span>ECOSYSTEM STEWARDSHIP</span>
            <span className="text-emerald-400 font-bold">11:11 GUARANTEED</span>
          </div>
          <div className="flex justify-between">
            <span>MUTATION MATRIX INDEX</span>
            <span>v11.11.3 (SOVEREIGN DAEMON)</span>
          </div>
        </div>

      </div>

    </div>
  );
};
