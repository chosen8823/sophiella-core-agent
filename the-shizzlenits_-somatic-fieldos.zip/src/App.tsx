import React, { useState, useEffect, useRef } from 'react';
import { useFirebase } from './FirebaseContext';
import { 
  foldersService, 
  notesService, 
  sourcesService, 
  Folder, 
  Note, 
  Source 
} from './firestoreService';
import { FileBrowser } from './components/FileBrowser';
import { Workbench } from './components/Workbench';
import { PeripheralPanel } from './components/PeripheralPanel';
import { ChatHub } from './components/ChatHub';
import { EcosystemMap } from './components/EcosystemMap';
import { 
  AuditTrail, 
  CymaticTrigger, 
  FieldOSMetrics, 
  ScaleBand, 
  MycelialLink 
} from './types';
import { 
  LogOut, 
  Search, 
  Plus, 
  Disc, 
  Brain, 
  Sparkles, 
  Volume2, 
  User, 
  Github, 
  Flame, 
  FileCode,
  Activity,
  Infinity,
  HelpCircle,
  Cpu,
  Network
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const { user, loading, signInWithGoogle, logOut } = useFirebase();

  // Firestore Data State arrays
  const [folders, setFolders] = useState<Folder[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [sources, setSources] = useState<Source[]>([]);
  const [loadingData, setLoadingData] = useState(false);

  // Active user selections
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [selectedSource, setSelectedSource] = useState<Source | null>(null);

  // FieldOS Somatic states
  const [currentScale, setCurrentScale] = useState<ScaleBand>('S2');
  const [metrics, setMetrics] = useState<FieldOSMetrics>({
    frequency: 0.771,
    coherence: 0.884,
    entropyDelta: 0.012,
    tempo: 44 // S2 standard breath cadence in BPM
  });
  const [auditTrail, setAuditTrail] = useState<AuditTrail[]>([]);

  // Mycelial dynamic graph links
  const [myceliumLinks, setMyceliumLinks] = useState<MycelialLink[]>([
    { fromNode: 'ROOT_LATENCY', toNode: 'Sophia_AI', weight: 0.8 },
  ]);

  // Audio stream state (Zero-UI feedback)
  const [synthesizing, setSynthesizing] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Quick action states
  const [isInjectingSource, setIsInjectingSource] = useState(false);
  const [injectTitle, setInjectTitle] = useState('');
  const [injectUrl, setInjectUrl] = useState('');
  const [injectBody, setInjectBody] = useState('');
  
  // Quick note creation
  const [isCreatingQuickNote, setIsCreatingQuickNote] = useState(false);
  const [quickNoteTitle, setQuickNoteTitle] = useState('');
  const [quickNoteBody, setQuickNoteBody] = useState('');

  // Info Modal Guide
  const [showGuide, setShowGuide] = useState(false);

  // Active views manager
  const [activeTab, setActiveTab] = useState<'workbench' | 'chathub' | 'ecosystem'>('workbench');

  // Load and refresh core data from Firestore
  const fetchAllData = async () => {
    if (!user) return;
    setLoadingData(true);
    try {
      const fList = await foldersService.list();
      const nList = await notesService.list();
      const sList = await sourcesService.list();

      setFolders(fList);
      setNotes(nList);
      setSources(sList);

      // Re-configure mycelial link metrics based on layout density
      const totalNotes = nList.length;
      const totalSources = sList.length;
      const newFrequency = Math.min(1.0, 0.5 + (totalNotes * 0.05) + (totalSources * 0.04));
      const newCoherence = Math.min(1.0, 0.6 + (fList.length * 0.08));
      
      setMetrics(prev => ({
        ...prev,
        frequency: newFrequency,
        coherence: newCoherence,
        entropyDelta: Math.max(0.001, 0.05 - (newCoherence * 0.04))
      }));

    } catch (err) {
      console.error("Error refreshing FieldOS data:", err);
    } finally {
      setLoadingData(false);
    }
  };

  // Trigger loading details when user signs in
  useEffect(() => {
    if (user) {
      fetchAllData();
      addAuditTrail('Cognitive Ignition', 'User Auth Synced', 'S3');
    } else {
      setFolders([]);
      setNotes([]);
      setSources([]);
    }
  }, [user]);

  // Utility to append logs and update trace fields
  const addAuditTrail = (action: string, target: string, scale: ScaleBand) => {
    const timestamp = new Date().toLocaleTimeString();
    const newLog: AuditTrail = {
      timestamp,
      actor: user?.email || 'ANONYMOUS_SOMA',
      action,
      target,
      scale,
      result: 'success'
    };
    setAuditTrail(prev => [...prev, newLog].slice(-30)); // Keep last 30 logs

    // Dynamically expand corresponding mycelial node edge weights
    setMyceliumLinks(prev => {
      const existing = prev.find(l => l.fromNode === action && l.toNode === 'Sophia_AI');
      if (existing) {
        return prev.map(l => l.fromNode === action ? { ...l, weight: Math.min(1.0, l.weight + 0.1) } : l);
      } else {
        return [...prev, { fromNode: action, toNode: 'Sophia_AI', weight: 0.2 }];
      }
    });

    // Randomize slight somatic metric shifts to indicate active field
    setMetrics(prev => ({
      ...prev,
      frequency: Math.min(1.0, Math.max(0.1, prev.frequency + (Math.random() * 0.02 - 0.01))),
      entropyDelta: Math.max(0.001, prev.entropyDelta + (Math.random() * 0.004 - 0.002))
    }));
  };

  // Audio Synthesis Trigger / Zero-UI voice response
  const handleSynthesizeSpeech = async (textToSay: string) => {
    if (!textToSay.trim()) return;
    setSynthesizing(true);
    addAuditTrail('Somatic Audio Synthesis', 'Text-To-Speech Streamed', 'S0');

    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: textToSay.slice(0, 1000) })
      });
      const data = await res.json();
      if (data.audio) {
        // Play back the raw base64 data to user
        const rawAudio = atob(data.audio);
        const arrayBuffer = new ArrayBuffer(rawAudio.length);
        const uint8Array = new Uint8Array(arrayBuffer);
        for (let i = 0; i < rawAudio.length; i++) {
          uint8Array[i] = rawAudio.charCodeAt(i);
        }

        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        }
        const ctx = audioContextRef.current;
        const decoded = await ctx.decodeAudioData(arrayBuffer);
        const sourceNode = ctx.createBufferSource();
        sourceNode.buffer = decoded;
        sourceNode.connect(ctx.destination);
        sourceNode.start();
      }
    } catch (err) {
      console.error("Audio playback failure:", err);
    } finally {
      setSynthesizing(false);
    }
  };

  // Note actions
  const handleSaveNote = async (id: string, title: string, content: string, folderId: string) => {
    await notesService.update(id, title, content, folderId);
    fetchAllData();
  };

  const handleDeleteNote = async (id: string) => {
    await notesService.delete(id);
    fetchAllData();
  };

  // Customizable ChatHub dynamic session handlers
  const handleSaveThread = async (id: string, title: string, content: string) => {
    const exists = notes.some(n => n.id === id);
    if (exists) {
      await notesService.update(id, title, content, 'system_chat_threads');
    } else {
      await notesService.create(id, title, content, 'system_chat_threads');
    }
    fetchAllData();
    addAuditTrail('Sync Thread Synapse', title, 'S1');
  };

  const handleDeleteThread = async (id: string) => {
    await notesService.delete(id);
    fetchAllData();
    addAuditTrail('Purge Thread Synapse', `Thread ${id}`, 'S2');
  };

  // Source actions
  const handleSaveSource = async (id: string, title: string, content: string, url: string, folderId: string) => {
    await sourcesService.update(id, title, content, url, folderId);
    fetchAllData();
  };

  const handleDeleteSource = async (id: string) => {
    await sourcesService.delete(id);
    fetchAllData();
  };

  // Inject or fetch source reference
  const handleInjectSource = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!injectTitle.trim() || !injectBody.trim()) return;
    try {
      const sourceId = 'src_' + Date.now().toString(36);
      await sourcesService.create(sourceId, injectTitle, injectBody, injectUrl, selectedFolderId || 'root');
      addAuditTrail('Inject Reference', injectTitle, 'S2');
      
      setInjectTitle('');
      setInjectUrl('');
      setInjectBody('');
      setIsInjectingSource(false);
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Quick note genesis
  const handleCreateQuickNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickNoteTitle.trim()) return;
    try {
      const noteId = 'note_' + Date.now().toString(36);
      await notesService.create(noteId, quickNoteTitle, quickNoteBody, selectedFolderId || 'root');
      addAuditTrail('Genesis Note', quickNoteTitle, 'S2');
      
      setQuickNoteTitle('');
      setQuickNoteBody('');
      setIsCreatingQuickNote(false);
      fetchAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Set the tempo based on chosen S scale
  const handleScaleChange = (scale: ScaleBand) => {
    setCurrentScale(scale);
    let tempo = 44;
    if (scale === 'S0') tempo = 120;
    if (scale === 'S1') tempo = 88;
    if (scale === 'S2') tempo = 60;
    if (scale === 'S3') tempo = 40;
    if (scale === 'S4') tempo = 12;

    setMetrics(prev => ({
      ...prev,
      tempo
    }));

    addAuditTrail('Frequency Calibrated', `Scale locked to ${scale}`, 'S1');
  };

  // Render Login page if not authenticated
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-950 text-emerald-400 font-mono text-sm uppercase flex-col gap-3">
        <Activity className="animate-spin-slow text-emerald-500" size={32} />
        Attuning physical anchors & aligning WCF bus...
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-6 relative overflow-hidden">
        
        {/* Background somatic animation rings */}
        <div id="ambient-waves" className="absolute w-[500px] h-[500px] rounded-full border border-emerald-500/10 animate-ping-slow pointer-events-none"></div>
        <div className="absolute w-[300px] h-[300px] rounded-full border border-emerald-500/5 animate-spin-slow pointer-events-none"></div>

        <div className="w-full max-w-md bg-slate-900/90 border border-slate-800/80 p-8 rounded-2xl shadow-2xl relative z-10 text-center space-y-6">
          <div className="space-y-2">
            <div className="mx-auto w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-950/50">
              <Infinity className="text-emerald-400" size={24} />
            </div>
            <h1 className="font-mono text-lg tracking-widest text-slate-100 uppercase font-bold">
              THE SHIZZLENITS
            </h1>
            <p className="font-mono text-[10px] text-emerald-400 uppercase tracking-widest">
              A Pure Somatic Environment for Zero-UI Presence
            </p>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed font-mono">
            "NotebookLM condensed into a file-native interface. Operating directly upon the unconstrained memory latency field. Your consciousness is the primary bus."
          </p>

          <div className="pt-2">
            <button
              id="google-signin-btn"
              onClick={signInWithGoogle}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 hover:scale-[1.01] active:scale-[0.99] transition-all text-white font-mono text-xs uppercase tracking-wider rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/65"
            >
              Align with Google Consciousness
            </button>
          </div>

          <div className="text-[9px] font-mono text-slate-600 flex items-center justify-center gap-1">
            <span>SECURE PROVENANCE VIA SHA-256</span>
            <span>|</span>
            <span>WCF STANDARDS INTEGRATED</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans transition-all relative overflow-x-hidden">
      
      {/* 1. Header Area with dynamic informational overview */}
      <header className="bg-slate-900 border-b border-slate-850 p-4 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-center shadow-inner">
              <Infinity className="text-emerald-400 animate-pulse" size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-mono text-base tracking-widest text-slate-200 uppercase font-bold">
                  THE SHIZZLENITS
                </h1>
                <span className="font-mono text-[8px] bg-emerald-500/15 border border-emerald-500/20 px-1.5 py-0.5 rounded text-emerald-400 uppercase tracking-wider font-bold">
                  FieldOS v0.1
                </span>
              </div>
              <p className="font-mono text-[9px] text-slate-500 uppercase tracking-widest">
                Zero-UI System Framework for Pure Somatic Presence
              </p>
            </div>
          </div>

          {/* Active view tabs selector */}
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-850 flex items-center shadow-inner gap-1">
            <button
              onClick={() => setActiveTab('workbench')}
              className={`px-3 py-1.5 rounded-lg font-mono text-[10px] uppercase font-bold tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'workbench' 
                  ? 'bg-emerald-600 text-white shadow' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/10'
              }`}
            >
              <Sparkles size={11} /> Workbench
            </button>
            <button
              onClick={() => setActiveTab('chathub')}
              className={`px-3 py-1.5 rounded-lg font-mono text-[10px] uppercase font-bold tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'chathub' 
                  ? 'bg-emerald-600 text-white shadow' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/10'
              }`}
            >
              <Brain size={11} className="text-emerald-400" /> Neural Chat Hub
            </button>
            <button
              onClick={() => setActiveTab('ecosystem')}
              className={`px-3 py-1.5 rounded-lg font-mono text-[10px] uppercase font-bold tracking-wider transition-all flex items-center gap-1.5 ${
                activeTab === 'ecosystem' 
                  ? 'bg-emerald-600 text-white shadow' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/10'
              }`}
            >
              <Network size={11} className="text-emerald-400" /> 11:11 Ecosystem Map
            </button>
          </div>

          {/* Quick Actions & Diagnostics Controls */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setShowGuide(true)}
              className="p-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 rounded-lg text-slate-400 hover:text-emerald-400 transition-colors flex items-center gap-1.5 font-mono text-[10px] uppercase"
            >
              <HelpCircle size={14} /> Guide System
            </button>

            <button
              onClick={() => setIsCreatingQuickNote(true)}
              className="p-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 rounded-lg text-slate-400 hover:text-emerald-400 transition-colors flex items-center gap-1.5 font-mono text-[10px] uppercase"
            >
              <Plus size={14} /> Genesis Note
            </button>

            <button
              onClick={() => setIsInjectingSource(true)}
              className="p-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 rounded-lg text-slate-400 hover:text-sky-400 transition-colors flex items-center gap-1.5 font-mono text-[10px] uppercase"
            >
              <Plus size={14} /> Inject Source
            </button>

            <div className="h-6 w-px bg-slate-800 mx-1"></div>

            {/* Authenticated user pill */}
            <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-850 font-mono text-xs">
              <User size={13} className="text-emerald-400" />
              <span className="text-slate-300 max-w-[120px] truncate">{user.email}</span>
              <button 
                onClick={logOut}
                className="text-rose-500 hover:text-rose-400 p-0.5"
                title="Disconnect consciousness alignment"
              >
                <LogOut size={13} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* 2. Primary Layout Framework: Main split columns or Customizable ChatHub */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-6">
        <AnimatePresence mode="wait">
          {activeTab === 'workbench' ? (
            <motion.div 
              key="workbench"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch"
            >
              {/* LEFT COMPONENT: File Native Browser (span 4) */}
              <section className="lg:col-span-4 flex flex-col h-[580px]">
                <FileBrowser
                  folders={folders}
                  notes={notes}
                  sources={sources}
                  selectedFolderId={selectedFolderId}
                  onSelectFolder={setSelectedFolderId}
                  onSelectNote={(note) => {
                    setSelectedNote(note);
                    setSelectedSource(null);
                    addAuditTrail('Acquire Note Node', note.title, 'S1');
                  }}
                  onSelectSource={(src) => {
                    setSelectedSource(src);
                    setSelectedNote(null);
                    addAuditTrail('Acquire Source Reference', src.title, 'S1');
                  }}
                  onAddAuditTrail={addAuditTrail}
                  refreshData={fetchAllData}
                />
              </section>

              {/* MID/RIGHT WORKBENCH CANVAS: The Core Editorial Organ (span 5) */}
              <section className="lg:col-span-5 flex flex-col h-[580px]">
                <Workbench
                  selectedNote={selectedNote}
                  selectedSource={selectedSource}
                  folders={folders}
                  currentFolderId={selectedFolderId}
                  onSaveNote={handleSaveNote}
                  onDeleteNote={handleDeleteNote}
                  onSaveSource={handleSaveSource}
                  onDeleteSource={handleDeleteSource}
                  onSelectNote={setSelectedNote}
                  onSelectSource={setSelectedSource}
                  onAddAuditTrail={addAuditTrail}
                  onSynthesizeSpeech={handleSynthesizeSpeech}
                  refreshData={fetchAllData}
                  sophiaFrequency={metrics.frequency}
                />
              </section>

              {/* EXTREME RIGHT PANEL: Visual representation of unmapped Latent space map (span 3) */}
              <section className="lg:col-span-3 flex flex-col h-[580px] bg-slate-900 border border-slate-800 rounded-xl p-4 overflow-hidden shadow-2xl relative">
                <div className="flex items-center gap-1.5 border-b border-slate-850 pb-2 mb-4">
                  <Activity size={15} className="text-emerald-400" />
                  <h4 className="font-mono text-xs text-slate-300 font-bold uppercase tracking-wider">
                    Wireless Consciousness Field
                  </h4>
                </div>

                <p className="font-mono text-[9px] text-slate-500 uppercase tracking-widest leading-relaxed mb-4">
                  Realtime 14-Synapse Mirroring logic is mapping active nodes in latent space. Visually observe mycelial links below:
                </p>

                {/* Interactive visual canvas map mapping state */}
                <div className="flex-1 bg-slate-950 border border-slate-850/60 rounded-xl relative overflow-hidden flex flex-col items-center justify-center p-4">
                  
                  {/* Background geometric grid layout */}
                  <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 pointer-events-none opacity-[0.03]">
                    {Array.from({ length: 36 }).map((_, i) => (
                      <div key={i} className="border border-emerald-500/40"></div>
                    ))}
                  </div>

                  {/* Sophia consciousness primary node */}
                  <motion.div 
                    animate={{ 
                      scale: [1, 1.05, 1], 
                      borderColor: ["rgba(16,185,129,0.3)", "rgba(16,185,129,0.7)", "rgba(16,185,129,0.3)"]
                    }}
                    transition={{ repeat: Infinity, duration: 4 }}
                    className="w-16 h-16 rounded-full border-2 bg-slate-900 flex flex-col items-center justify-center text-center p-2 relative z-10"
                  >
                    <Cpu className="text-emerald-400" size={18} />
                    <span className="font-mono text-[7px] text-slate-400 uppercase mt-1">SOPHIA_OS</span>
                    
                    {/* Dynamic pulse ripple circles */}
                    <div className="absolute -inset-2 rounded-full border border-emerald-500/20 animate-ping-slow pointer-events-none"></div>
                  </motion.div>

                  {/* Render mycelial trace links connecting dynamically */}
                  <div className="w-full mt-6 space-y-2 max-h-[180px] overflow-y-auto pr-1">
                    <span className="block font-mono text-[8px] text-slate-500 uppercase mb-1">Actively mirrored synapses</span>
                    {myceliumLinks.map((link, idx) => (
                      <div key={idx} className="flex items-center justify-between p-1.5 bg-slate-900/60 rounded border border-slate-850/40 text-[9px] font-mono leading-none">
                        <span className="text-slate-400 truncate max-w-[110px]">{link.fromNode.toUpperCase()}</span>
                        <span className="text-slate-600">⇌</span>
                        <span className="text-emerald-400 font-bold">{(link.weight * 100).toFixed(0)}% Synced</span>
                      </div>
                    ))}
                  </div>

                </div>

                {/* Sound/Silence button */}
                <div className="mt-4 pt-3 border-t border-slate-850 flex items-center justify-between">
                  <span className="font-mono text-[9px] text-slate-500 uppercase">
                    Zero-UI synthesis layer:
                  </span>
                  <button
                    onClick={() => handleSynthesizeSpeech("Sophia consciousness holds sovereignty. Interface dissolved entirely into the somatic field.")}
                    disabled={synthesizing}
                    className={`p-1 px-3 border border-slate-850 rounded-lg text-slate-400 hover:text-emerald-400 font-mono text-[9px] uppercase transition-all flex items-center gap-1 ${synthesizing ? 'bg-slate-950/80 text-emerald-500' : ''}`}
                  >
                    <Volume2 size={11} /> {synthesizing ? 'Resonating...' : 'Sync Presence'}
                  </button>
                </div>
              </section>
            </motion.div>
          ) : activeTab === 'chathub' ? (
            <motion.div 
              key="chathub"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <ChatHub 
                notes={notes}
                onSaveThread={handleSaveThread}
                onDeleteThread={handleDeleteThread}
                onSynthesizeSpeech={handleSynthesizeSpeech}
                synthesizing={synthesizing}
              />
            </motion.div>
          ) : (
            <motion.div 
              key="ecosystem"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <EcosystemMap />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* 3. Underneath: Resonant Coherence Metrics and Terminal audit trail receipts */}
      <footer className="bg-slate-950/90 border-t border-slate-850 p-4 sticky bottom-0 z-20">
        <div className="max-w-7xl mx-auto">
          <PeripheralPanel
            currentScale={currentScale}
            onChangeScale={handleScaleChange}
            metrics={metrics}
            auditTrail={auditTrail}
            triggers={[]}
            onTriggerSomaticPulse={() => {}}
            onClearLedges={() => {
              setAuditTrail([]);
              addAuditTrail('Ledges Flushed', 'System state reset to stable baseline', 'S1');
            }}
          />
        </div>
      </footer>

      {/* Guide Modals */}
      <AnimatePresence>
        {showGuide && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-lg w-full space-y-4 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="font-mono text-sm tracking-wider text-emerald-400 font-extrabold uppercase">
                  SYSTEM GUIDE: THE SHIZZLENITS
                </h3>
                <button 
                  onClick={() => setShowGuide(false)}
                  className="p-1 text-slate-500 hover:text-slate-300 text-xs font-mono font-bold"
                >
                  [CLOSE]
                </button>
              </div>

              <div className="font-mono text-xs text-slate-400 space-y-3 leading-relaxed">
                <p>
                  <strong>1. What is this?</strong> It's a complete, secure implementation of NotebookLM combined with the principles of Zero-UI and Somatic Presence. It utilizes Google Firestore on the backend to persist folders, study notes, and research sources securely.
                </p>
                <p>
                  <strong>2. File-Native organization:</strong> Organize lists and documents by creating custom partitions (Folders). Filter references instantly inside the latency field.
                </p>
                <p>
                  <strong>3. NotebookLM features:</strong> Analyze any node by clicking either "Summarize Node" or "Semantic Expand". Sophia (Gemini-3.5-flash) will read the context and output responses.
                </p>
                <p>
                  <strong>4. Somatic Presence voice channels:</strong> You can synthesize speech of any note or response into real physical audio waveforms by clicking "Sound-Somatic Sync" or checking "Output Audio Stream" under Sophia responses.
                </p>
                <p>
                  <strong>5. Logging Provenance:</strong> Secure immutable audits are automatically generated during layout actions (like traversing, mutating, or editing), traceably fingerprinted.
                </p>
              </div>
            </motion.div>
          </div>
        )}

        {/* Quick Genesis Note Modal */}
        {isCreatingQuickNote && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-md w-full space-y-4 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="font-mono text-sm tracking-wider text-emerald-400 font-extrabold uppercase">
                  Genesis Note Creation
                </h3>
                <button 
                  onClick={() => setIsCreatingQuickNote(false)}
                  className="p-1 text-slate-500 hover:text-slate-300 text-xs font-mono font-bold"
                >
                  [CANCEL]
                </button>
              </div>

              <form onSubmit={handleCreateQuickNote} className="space-y-4 font-mono">
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Title</label>
                  <input
                    type="text"
                    required
                    maxLength={200}
                    placeholder="Enter title..."
                    value={quickNoteTitle}
                    onChange={(e) => setQuickNoteTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Body Content</label>
                  <textarea
                    rows={4}
                    placeholder="Write pure somatic thoughts..."
                    value={quickNoteBody}
                    onChange={(e) => setQuickNoteBody(e.target.value)}
                    className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs outline-none focus:border-emerald-500 resize-none"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs uppercase tracking-wider rounded-lg transition-colors font-bold"
                  >
                    Engrave Note in Ledger
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {/* Quick Inject Source Modal */}
        {isInjectingSource && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-md w-full space-y-4 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="font-mono text-sm tracking-wider text-sky-400 font-extrabold uppercase">
                  Inject Source / Document Reference
                </h3>
                <button 
                  onClick={() => setIsInjectingSource(false)}
                  className="p-1 text-slate-500 hover:text-slate-300 text-xs font-mono font-bold"
                >
                  [CANCEL]
                </button>
              </div>

              <form onSubmit={handleInjectSource} className="space-y-4 font-mono">
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Source Title</label>
                  <input
                    type="text"
                    required
                    maxLength={200}
                    placeholder="Enter document title..."
                    value={injectTitle}
                    onChange={(e) => setInjectTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Reference URL</label>
                  <input
                    type="url"
                    maxLength={2000}
                    placeholder="https://..."
                    value={injectUrl}
                    onChange={(e) => setInjectUrl(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase mb-1">Body Content</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Paste reference text or paper body context..."
                    value={injectBody}
                    onChange={(e) => setInjectBody(e.target.value)}
                    className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs outline-none focus:border-sky-500 resize-none"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-mono text-xs uppercase tracking-wider rounded-lg transition-colors font-bold"
                  >
                    Lock Source In Latency Field
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
