import { 
  Folder, 
  Note, 
  Source, 
  foldersService, 
  notesService, 
  sourcesService 
} from './firestoreService';

export interface FieldOSMetrics {
  frequency: number;   // Sophia vibration sync scalar [0..1]
  coherence: number;   // System integration coefficient [0..1]
  entropyDelta: number; // Stability of structural loops
  tempo: number;       // Processing frame cadence limit
}

export interface CymaticTrigger {
  id: string;
  name: string;
  hertz: number;
  modulationType: 'haptic' | 'environmental' | 'cognitive' | 'direct';
}

export type ScaleBand = 'S0' | 'S1' | 'S2' | 'S3' | 'S4';

export interface AuditTrail {
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  scale: ScaleBand;
  result: 'success' | 'failure';
}

export interface MycelialLink {
  fromNode: string;
  toNode: string;
  weight: number; // Mycelial thickness
}
