
function sampleText() {
  const text = document.body?.innerText || "";
  return text.slice(0, 1200);
}

function snapshot() {
  return {
    url: location.href,
    title: document.title,
    text: sampleText(),
    time: Date.now()
  };
}

setInterval(() => {
  chrome.runtime.sendMessage({
    type: "WORLD_SNAPSHOT",
    payload: snapshot()
  });
}, 2500);

const panel = document.createElement("div");

panel.style.position = "fixed";
panel.style.bottom = "10px";
panel.style.right = "10px";
panel.style.width = "220px";
panel.style.padding = "10px";
panel.style.background = "rgba(0,0,0,0.75)";
panel.style.color = "#00ffff";
panel.style.fontSize = "12px";
panel.style.fontFamily = "monospace";
panel.style.zIndex = "999999";
panel.style.border = "1px solid #0ff";

panel.innerText = "skeez field: initializing...";

document.body.appendChild(panel);

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== "SKEEZ_UPDATE") return;

  const p = msg.payload;

  panel.innerText =
`SKEEZ FIELD
-----------
state: ${p.state}
energy: ${p.energy}
nodes: ${p.nodes}`;
});
