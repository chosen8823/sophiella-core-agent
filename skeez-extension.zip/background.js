
function phoneticize(text) {
  return text.toLowerCase().replace(/[^a-z]/g, "");
}

async function sha(bytes) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(bytes));
  return Array.from(new Uint8Array(buf));
}

function hashToField(hash) {
  const freq = [];
  const amp = [];

  for (let i = 0; i < hash.length; i += 2) {
    freq.push(40 + hash[i]);
    amp.push(hash[i + 1] / 255);
  }

  return { freq, amp };
}

function detectState(field) {
  const energy = field.amp.reduce((a, b) => a + b, 0);

  if (energy > 10) return "HIGH_FLUID";
  if (energy > 5) return "FLOWING";
  return "DORMANT";
}

chrome.runtime.onMessage.addListener(async (msg) => {
  if (msg.type !== "WORLD_SNAPSHOT") return;

  const phon = phoneticize(msg.payload.text);
  const hash = await sha(phon);
  const field = hashToField(hash);
  const state = detectState(field);

  chrome.runtime.sendMessage({
    type: "SKEEZ_UPDATE",
    payload: {
      state,
      energy: field.amp.reduce((a,b)=>a+b,0).toFixed(2),
      nodes: field.freq.length
    }
  });
});
