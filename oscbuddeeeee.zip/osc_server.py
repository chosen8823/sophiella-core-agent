"""
osc_server.py  —  Living Engine OS · OSC RX bridge
Listens on 192.168.1.234:8000 for incoming OSC bundles
from the browser controller and dispatches to AI handler.

Install:  pip install python-osc
Run:      python osc_server.py
"""

import json
import time
import threading
from pythonosc import dispatcher as osc_dispatcher
from pythonosc import osc_server as osc_srv
from pythonosc import udp_client

# ── config ────────────────────────────────────────────────
HOST        = "192.168.1.234"
RX_PORT     = 8000        # this server listens here
TX_PORT     = 8001        # sends feedback back out here
AI_LOG      = "osc_log.jsonl"   # append-only event log
# ─────────────────────────────────────────────────────────

client = udp_client.SimpleUDPClient(HOST, TX_PORT)

state = {
    "/audio/amp":    0.0,
    "/audio/freq":   0.0,
    "/midi/pitch":   0.0,
    "/io/trig":      0.0,
    "/ai/feedback":  0.0,
    "/ai/morph":     0.0,
}

def log_event(addr, value):
    entry = {"ts": time.time(), "addr": addr, "value": value}
    with open(AI_LOG, "a") as f:
        f.write(json.dumps(entry) + "\n")
    print(f"  RX  {addr:<20} {value:.4f}")

# ── address handlers ──────────────────────────────────────

def handle_amp(addr, *args):
    v = float(args[0]) if args else 0.0
    state[addr] = v
    log_event(addr, v)
    # mirror back with slight AI transform
    client.send_message("/ai/feedback", round(v * 0.85 + 0.05, 4))

def handle_freq(addr, *args):
    v = float(args[0]) if args else 0.0
    state[addr] = v
    log_event(addr, v)
    client.send_message("/ai/morph", round(v ** 0.7, 4))

def handle_pitch(addr, *args):
    v = float(args[0]) if args else 0.0
    state[addr] = v
    log_event(addr, v)

def handle_trig(addr, *args):
    v = float(args[0]) if args else 0.0
    state[addr] = v
    log_event(addr, v)
    if v >= 0.9:
        print(f"  ⚡  TRIGGER fired — broadcasting state snapshot")
        client.send_message("/ai/snapshot", json.dumps(state))

def handle_generic(addr, *args):
    v = float(args[0]) if args else 0.0
    state[addr] = v
    log_event(addr, v)

def handle_default(addr, *args):
    print(f"  ??  unhandled {addr}  args={args}")

# ── dispatcher ────────────────────────────────────────────

def build_dispatcher():
    d = osc_dispatcher.Dispatcher()
    d.map("/audio/amp",   handle_amp)
    d.map("/audio/freq",  handle_freq)
    d.map("/midi/pitch",  handle_pitch)
    d.map("/io/trig",     handle_trig)
    d.map("/ai/*",        handle_generic)
    d.set_default_handler(handle_default)
    return d

# ── heartbeat — sends state snapshot every 5 s ───────────

def heartbeat():
    while True:
        time.sleep(5)
        client.send_message("/ai/heartbeat", json.dumps(state))
        print(f"  ♡   heartbeat TX → {HOST}:{TX_PORT}")

# ── main ──────────────────────────────────────────────────

if __name__ == "__main__":
    d = build_dispatcher()
    server = osc_srv.ThreadingOSCUDPServer((HOST, RX_PORT), d)
    print(f"\n  Living Engine OS · OSC Bridge")
    print(f"  RX  {HOST}:{RX_PORT}")
    print(f"  TX  {HOST}:{TX_PORT}")
    print(f"  log → {AI_LOG}\n")

    t = threading.Thread(target=heartbeat, daemon=True)
    t.start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  OSC server stopped.")
