# Living Engine OS — OSC Bridge Suite

Three scripts that wire your browser OSC controller
into a Python AI feedback loop.

## Files

| File | Role |
|---|---|
| `osc_server.py` | Pure RX listener — logs all incoming OSC, mirrors transforms back out |
| `osc_client.py` | TX client — send values to any OSC listener from Python |
| `osc_ai_bridge.py` | Full loop — RX + AI inference + TX back into the controller |

## Your network

- Host IP : `192.168.1.234`
- RX port : `8000`  ← browser controller sends here
- TX port : `8001`  ← Python sends AI values back here
- Active ports preserved: 22 (SSH), 554 (RTSP), 3389 (RDP), 7250, 27036 (Steam)

## Quick start

```bash
pip install python-osc

# Option 1 — just the server (log + mirror)
python osc_server.py

# Option 2 — full AI feedback loop (no API key needed)
BACKEND=local python osc_ai_bridge.py

# Option 3 — Claude as the AI layer
set ANTHROPIC_API_KEY=your_key_here
BACKEND=anthropic python osc_ai_bridge.py

# Option 4 — ChatGPT / SOPHIA as the AI layer
set OPENAI_API_KEY=your_key_here
BACKEND=openai python osc_ai_bridge.py
```

## OSC address map

| Address | Direction | Type | Description |
|---|---|---|---|
| `/audio/amp` | RX | float 0–1 | Amplitude envelope |
| `/audio/freq` | RX | float 0–1 | Frequency (normalized) |
| `/midi/pitch` | RX | float 0–1 | Pitch / CC1 |
| `/io/trig` | RX | float 0–1 | Trigger gate |
| `/ai/feedback` | TX | float 0–1 | AI-computed feedback scalar |
| `/ai/morph` | TX | float 0–1 | Morphogenetic parameter |
| `/ai/text` | TX | string | AI text response (max 255 chars) |
| `/ai/snapshot` | TX | JSON string | Full state snapshot on trigger |
| `/ai/heartbeat` | TX | JSON string | State broadcast every 5 s |

## Import as a module

```python
from osc_client import OSCClient

c = OSCClient()
c.send_feedback(0.72)
c.send_morph(0.45)
c.send_bundle({"amp": 0.6, "freq": 0.3, "morph": 0.8})
c.send_ai_response("morph shift initiated", {"morph": 0.9, "feedback": 0.5})
```

## WhobitQ / Gradienta11y integration

Import `OSCClient` into your Architect/Builder/Reviewer pipeline:

```python
# In your WhobitQ agent cycle (modulo step)
from osc_client import OSCClient
osc = OSCClient()

# After each agent decision
osc.send_bundle({
    "feedback": agent_confidence,
    "morph":    pipeline_stage / total_stages,
    "trig":     1.0 if pipeline_complete else 0.0,
})
```
