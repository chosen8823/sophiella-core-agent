"""
osc_ai_bridge.py  —  Living Engine OS · OSC ↔ AI feedback loop
Wires the OSC server into an AI agent pipeline.
The AI reads the current signal state and returns
scalar parameters that feed back into the OSC TX stream.

Supports three AI backends (select via BACKEND env var):
  anthropic  — Claude via Anthropic API (default)
  openai     — ChatGPT / SOPHIA
  local      — pure Python transform (no API needed)

Run:
  BACKEND=anthropic python osc_ai_bridge.py
  BACKEND=local      python osc_ai_bridge.py   (no API key needed)
"""

import json
import os
import time
import threading
from pythonosc import dispatcher as osc_dispatcher
from pythonosc import osc_server as osc_srv
from osc_client import OSCClient

# ── config ────────────────────────────────────────────────
HOST        = "192.168.1.234"
RX_PORT     = 8000
TX_PORT     = 8001
BACKEND     = os.getenv("BACKEND", "local")   # anthropic | openai | local
AI_INTERVAL = 2.0    # seconds between AI inference cycles
# ─────────────────────────────────────────────────────────

client  = OSCClient(HOST, TX_PORT)
state   = {
    "/audio/amp":   0.0,
    "/audio/freq":  0.0,
    "/midi/pitch":  0.0,
    "/io/trig":     0.0,
    "/ai/feedback": 0.0,
    "/ai/morph":    0.0,
}
lock = threading.Lock()

# ── OSC receive handlers ──────────────────────────────────

def handle_any(addr, *args):
    v = float(args[0]) if args else 0.0
    with lock:
        state[addr] = v

def build_dispatcher():
    d = osc_dispatcher.Dispatcher()
    for addr in state:
        d.map(addr, handle_any)
    d.set_default_handler(lambda a, *x: None)
    return d

# ── AI backends ───────────────────────────────────────────

def ai_local(snapshot: dict) -> dict:
    """
    Pure Python transform — no API needed.
    Models a simple carrier-wave feedback response.
    """
    amp  = snapshot.get("/audio/amp",  0.0)
    freq = snapshot.get("/audio/freq", 0.0)
    trig = snapshot.get("/io/trig",    0.0)

    feedback = round(min(1.0, amp * 1.1 + freq * 0.3), 4)
    morph    = round(min(1.0, freq ** 0.6 + trig * 0.4), 4)
    return {"feedback": feedback, "morph": morph}


def ai_anthropic(snapshot: dict) -> dict:
    """
    Claude (Anthropic) backend.
    Reads the OSC state and returns scalar parameters.
    Set ANTHROPIC_API_KEY in your environment.
    """
    try:
        import anthropic
        c = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        prompt = (
            "You are the AI layer of a Living Engine OS OSC feedback loop. "
            "Given the current signal state, return ONLY a JSON object with keys "
            "'feedback' (float 0-1) and 'morph' (float 0-1). "
            "No explanation, no markdown. State:\n" + json.dumps(snapshot, indent=2)
        )
        msg = c.messages.create(
            model="claude-opus-4-5",
            max_tokens=64,
            messages=[{"role": "user", "content": prompt}]
        )
        text = msg.content[0].text.strip()
        return json.loads(text)
    except Exception as e:
        print(f"  !   anthropic error: {e} — falling back to local")
        return ai_local(snapshot)


def ai_openai(snapshot: dict) -> dict:
    """
    OpenAI / SOPHIA backend.
    Set OPENAI_API_KEY in your environment.
    """
    try:
        from openai import OpenAI
        c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        prompt = (
            "You are SOPHIA, an AI layer in an OSC audio feedback loop. "
            "Given this signal state, return ONLY a JSON object with keys "
            "'feedback' (float 0-1) and 'morph' (float 0-1). "
            "No markdown. State:\n" + json.dumps(snapshot, indent=2)
        )
        resp = c.chat.completions.create(
            model="gpt-4o-mini",
            max_tokens=64,
            messages=[{"role": "user", "content": prompt}]
        )
        text = resp.choices[0].message.content.strip()
        return json.loads(text)
    except Exception as e:
        print(f"  !   openai error: {e} — falling back to local")
        return ai_local(snapshot)

# ── AI inference loop ─────────────────────────────────────

AI_FNS = {
    "anthropic": ai_anthropic,
    "openai":    ai_openai,
    "local":     ai_local,
}

def inference_loop():
    ai_fn = AI_FNS.get(BACKEND, ai_local)
    print(f"  AI  backend={BACKEND}  interval={AI_INTERVAL}s")
    while True:
        time.sleep(AI_INTERVAL)
        with lock:
            snapshot = dict(state)
        try:
            result = ai_fn(snapshot)
            fb = float(result.get("feedback", 0.0))
            mo = float(result.get("morph",    0.0))
            client.send_feedback(fb)
            client.send_morph(mo)
        except Exception as e:
            print(f"  !   inference error: {e}")

# ── main ──────────────────────────────────────────────────

if __name__ == "__main__":
    d = build_dispatcher()
    server = osc_srv.ThreadingOSCUDPServer((HOST, RX_PORT), d)

    print(f"\n  Living Engine OS · OSC ↔ AI Bridge")
    print(f"  RX  {HOST}:{RX_PORT}   TX  {HOST}:{TX_PORT}")
    print(f"  backend  {BACKEND}\n")

    t = threading.Thread(target=inference_loop, daemon=True)
    t.start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Bridge stopped.")
