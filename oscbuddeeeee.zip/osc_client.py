"""
osc_client.py  —  Living Engine OS · OSC TX client
Sends AI-computed values back to the browser controller
(or any OSC listener on TX_PORT).

Usage:
  from osc_client import OSCClient
  c = OSCClient()
  c.send_feedback(0.72)
  c.send_morph(0.45)
  c.send_bundle({"amp": 0.6, "freq": 0.3, "morph": 0.8})
"""

import json
import time
from pythonosc import udp_client
from pythonosc.osc_bundle_builder import OscBundleBuilder
from pythonosc.osc_message_builder import OscMessageBuilder
import pythonosc.osc_bundle_builder as bundle_builder

HOST     = "192.168.1.234"
TX_PORT  = 8001

class OSCClient:
    def __init__(self, host=HOST, port=TX_PORT):
        self.client = udp_client.SimpleUDPClient(host, port)
        self.host = host
        self.port = port
        print(f"  OSCClient → {host}:{port}")

    # ── single sends ──────────────────────────────────────

    def send_feedback(self, value: float):
        """AI feedback scalar (0.0–1.0)"""
        v = max(0.0, min(1.0, float(value)))
        self.client.send_message("/ai/feedback", v)
        print(f"  TX  /ai/feedback       {v:.4f}")

    def send_morph(self, value: float):
        """Morphogenetic parameter (0.0–1.0)"""
        v = max(0.0, min(1.0, float(value)))
        self.client.send_message("/ai/morph", v)
        print(f"  TX  /ai/morph          {v:.4f}")

    def send_trigger(self, value: float = 1.0):
        """Fire a trigger gate"""
        self.client.send_message("/io/trig", float(value))
        print(f"  TX  /io/trig           {value:.4f}")

    def send_raw(self, address: str, value):
        """Send to any OSC address"""
        self.client.send_message(address, value)
        print(f"  TX  {address:<20} {value}")

    # ── bundle send ───────────────────────────────────────

    def send_bundle(self, params: dict):
        """
        Send a full parameter bundle.
        Keys map to OSC addresses:
          amp, freq, pitch, trig → /audio/* /midi/* /io/*
          feedback, morph        → /ai/*
          anything else          → /custom/<key>
        """
        addr_map = {
            "amp":      "/audio/amp",
            "freq":     "/audio/freq",
            "pitch":    "/midi/pitch",
            "trig":     "/io/trig",
            "feedback": "/ai/feedback",
            "morph":    "/ai/morph",
        }
        builder = OscBundleBuilder(bundle_builder.IMMEDIATELY)
        for key, value in params.items():
            addr = addr_map.get(key, f"/custom/{key}")
            msg = OscMessageBuilder(address=addr)
            msg.add_arg(float(value))
            builder.add_content(msg.build())
            print(f"  TX  {addr:<20} {float(value):.4f}")
        self.client.send_bundle(builder.build())

    # ── AI response sender ────────────────────────────────

    def send_ai_response(self, response_text: str, scalar_map: dict = None):
        """
        Package an AI text response as OSC.
        Sends /ai/text (string) + optional scalar bundle.
        """
        self.client.send_message("/ai/text", response_text[:255])
        print(f"  TX  /ai/text           \"{response_text[:40]}...\"")
        if scalar_map:
            self.send_bundle(scalar_map)


# ── quick test ────────────────────────────────────────────

if __name__ == "__main__":
    c = OSCClient()
    print("\n  Sending test bundle...\n")

    c.send_bundle({
        "amp":      0.72,
        "freq":     0.45,
        "feedback": 0.88,
        "morph":    0.33,
    })

    time.sleep(0.5)
    c.send_trigger(1.0)
    time.sleep(0.2)
    c.send_trigger(0.0)

    print("\n  Done.")
